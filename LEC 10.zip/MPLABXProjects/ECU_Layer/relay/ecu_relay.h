/*
 * File:   ecu_relay.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 12:09 AM
 */

#ifndef ECU_RELAY_H
#define ECU_RELAY_H

/*  Section :   includes    */
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "ecu_relay_config.h"

/*  Section :   Macro Declarations    */

#define RELAY_ON 0x01U
#define RELAY_OFF 0x00U

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */
typedef struct
{
    uint8 relay_port : 4;
    uint8 relay_pin : 3;
    uint8 relay_status : 1;
} Relay_t;

/*  Section :   Function Declarations    */

/**
 * @brief initializes the relay pin
 *
 * @param relay is a pointer to the relay object
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType relay_init(const Relay_t *relay);

/**
 * @brief turns on the relay
 *
 * @param relay is a pointer to the relay object
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType relay_turn_on(const Relay_t *relay);

/**
 * @brief   turns off the relay
 *
 * @param relay is a pointer to the relay object
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType relay_turn_off(const Relay_t *relay);

#endif /* ECU_RELAY_H */
