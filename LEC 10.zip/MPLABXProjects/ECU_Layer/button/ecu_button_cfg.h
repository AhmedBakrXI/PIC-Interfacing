/*
 * File:   ecu_button_cfg.h
 * Author: AHMED BAKR
 *
 * Created on July 20, 2023, 6:55 PM
 */

#ifndef ECU_BUTTON_CFG_H
#define ECU_BUTTON_CFG_H

#endif /* ECU_BUTTON_CFG_H */
