/*
 * File:   ecu_7seg.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 9:37 PM
 */

#ifndef ECU_7SEG_H
#define ECU_7SEG_H

/*  Sec:    Includes    */
#include "ecu_7seg_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*  Sec:    Macros Definition   */

#define SEG_PIN0 0
#define SEG_PIN1 1
#define SEG_PIN2 2
#define SEG_PIN3 3

/*  Sec:    User Defined Data Types*/
typedef enum
{
    COMMON_CATHODE,
    COMMON_ANODE
} segment_type_t;

typedef struct
{
    pin_config_t seg_pins[4];
    segment_type_t segment_type;
} Segment_t;

/*  Sec:    Functions Declaration*/

/**
 * @brief   used to initialize 7-segment display
 *
 * @param _segment  pointer to segment configurations
 * @return  Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType seven_seg_init(const Segment_t *_segment);

/**
 * @brief   used to write a number on 7-segment display
 *
 * @param _segment  pointer to segment configurations
 * @param number    number to be displayed
 * @return  Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType seven_seg_write(const Segment_t *_segment, uint8 number);

#endif /* ECU_7SEG_H */
