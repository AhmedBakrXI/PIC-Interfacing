/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

void handler(void);

uint8 i = 0;

led_t led = {
    .port = PORTC_INDEX,
    .pin = PIN0,
    .status = LED_OFF,
};

Timer0_t timer = {
    .interrupt_handler = handler,
    .counter_edge = TIMER0_RISING_EDGE,
    .preload_value = 0xFFFA,
    .prescalar_status = TIMER0_PRESCALAR_FEATURE_DISABLE,
    .register_size = TIMER0_REGISTER_16BIT_SIZE,
    .timer0_mode = TIMER0_COUNTER_CFG,
    .TMR0_interrupt_priority = INTERRUPT_HIGH_PRIORITY,
};

Std_ReturnType ret = E_NOT_OK;


int main()
{

    Timer0_init(&timer);
    led_initialize(&led);
    while (1)
    {
    }

    return (EXIT_SUCCESS);
}

void handler(void)
{
    i++;
    led_turn_toggle(&led);
}

void app_init(void)
{
    ecu_layer_init();
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt

Ahmed Mohammed Bakr     27July2023      Task-12 build mcal EEPROM interrupt

Ahmed Mohammed Bakr     30July2023      Task-13 build mcal ADC

******************************************************************* */
