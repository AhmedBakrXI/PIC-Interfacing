#include "mcal_timer0.h"

static uint16 timer0_preload = ZERO_INIT;

static inline void Timer0_prescalar_config(const Timer0_t *timer);
static inline void Timer0_mode_config(const Timer0_t *timer);
static inline void Timer0_register_size(const Timer0_t *timer);

#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*TMR0_interrupt_handler)(void) = NULL;
#endif

Std_ReturnType Timer0_init(const Timer0_t *_timer0)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer0)
    {
        ret = E_NOT_OK;
    }
    else
    {
        // Disable timer0 module
        TIMER0_DISABLE();
#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GLOBAL_ENABLE();
        INTERRUPT_PERIPHERAL_ENABLE();
        TIMER0_INTERRUPT_ENABLE();
        TIMER0_INTERRUPT_FLAG_CLEAR();
        TMR0_interrupt_handler = _timer0->interrupt_handler;
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_FEATURE_ENABLE();
        if (INTERRUPT_HIGH_PRIORITY == _timer0->TMR0_interrupt_priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            TIMER0_INTERRUPT_PRIORITY_HIGH();
        }
        else if (INTERRUPT_LOW_PRIORITY == _timer0->TMR0_interrupt_priority)
        {
            INTERRUPT_GLOBAL_LOW_ENABLE();
            TIMER0_INTERRUPT_PRIORITY_LOW();
        }
        else
        {
            /* NOTHING */
        }
#endif
#endif

        Timer0_prescalar_config(_timer0);
        Timer0_mode_config(_timer0);
        Timer0_register_size(_timer0);
        TMR0H = ((_timer0->preload_value) >> 8);
        TMR0L = (uint8)(_timer0->preload_value);
        timer0_preload = _timer0->preload_value;
        // Enable timer0 module
        TIMER0_ENABLE();
    }
    return ret;
}

Std_ReturnType Timer0_deinit(const Timer0_t *_timer0)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer0)
    {
        ret = E_NOT_OK;
    }
    else
    {
        // Disable timer0 module
        TIMER0_DISABLE();
#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER0_INTERRUPT_DISABLE();
#endif
    }
    return ret;
}

Std_ReturnType Timer0_write(const Timer0_t *_timer0, uint16 _value)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer0)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TMR0H = (_value >> 8);
        TMR0L = (uint8)(_value);
    }
    return ret;
}

Std_ReturnType Timer0_read(const Timer0_t *_timer0, uint16 *_value)
{
    Std_ReturnType ret = E_OK;
    uint8 l_tmr0h = ZERO_INIT, l_tmr0l = ZERO_INIT;

    if ((NULL == _timer0) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        l_tmr0l = TMR0L;
        l_tmr0h = TMR0H;

        *_value = (uint16)(l_tmr0h << 8) + (l_tmr0l);
    }
    return ret;
}

void Timer0_ISR(void)
{
    TIMER0_INTERRUPT_FLAG_CLEAR();

    TMR0H = (timer0_preload >> 8);
    TMR0L = (uint8)(timer0_preload);

    if (TMR0_interrupt_handler)
    {
        TMR0_interrupt_handler();
    }
}

static inline void Timer0_prescalar_config(const Timer0_t *timer)
{
    if (TIMER0_PRESCALAR_FEATURE_ENABLE == timer->prescalar_status)
    {
        TIMER0_PRESCALAR_ENABLE();
        TIMER0_SET_PRESCALAR(timer->prescalar);
    }
    else if (TIMER0_PRESCALAR_FEATURE_DISABLE == timer->prescalar_status)
    {
        TIMER0_PRESCALAR_DISABLE();
    }
    else
    {
        /* Nothing */
    }
}

static inline void Timer0_mode_config(const Timer0_t *timer)
{
    if (TIMER0_TIMER_CFG == timer->timer0_mode)
    {
        TIMER0_TIMER_MODE();
    }
    else if (TIMER0_COUNTER_CFG == timer->timer0_mode)
    {
        TIMER0_COUNTER_MODE();
        if (TIMER0_RISING_EDGE == timer->counter_edge)
        {
            TIMER0_INC_RISING_EDGE();
        }
        else if (TIMER0_FALLING_EDGE == timer->counter_edge)
        {
            TIMER0_INC_FALLING_EDGE();
        }
        else
        {
            /* NOTHING */
        }
    }
}

static inline void Timer0_register_size(const Timer0_t *timer)
{
    if (TIMER0_REGISTER_8BIT_SIZE == timer->register_size)
    {
        TIMER0_8BIT_MODE();
    }
    else if (TIMER0_REGISTER_16BIT_SIZE == timer->register_size)
    {
        TIMER0_16BIT_MODE();
    }
    else
    {
        /* Hmm.., NOTHING NOTHING NOTHING Gonna save us now */
    }
}