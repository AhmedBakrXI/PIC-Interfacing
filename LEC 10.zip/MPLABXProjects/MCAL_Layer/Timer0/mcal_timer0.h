/*
 * File:   device_config.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:50 PM
 */

#ifndef MCAL_TIMER0_H
#define MCAL_TIMER0_H

/*  Section :   includes    */
#include "../../pic18f4620.h"
#include "../GPIO/hal_gpio.h"
#include "../mcal_std_types.h"
#include "../Interrupt/mcal_internal_interrupt.h"


/*  Section :   Macro Declarations    */
#define TIMER0_REGISTER_8BIT_SIZE            1
#define TIMER0_REGISTER_16BIT_SIZE           0

#define TIMER0_PRESCALAR_FEATURE_ENABLE      1
#define TIMER0_PRESCALAR_FEATURE_DISABLE     0

#define TIMER0_RISING_EDGE                   1
#define TIMER0_FALLING_EDGE                  0

#define TIMER0_TIMER_CFG                     1
#define TIMER0_COUNTER_CFG                   0

/*  Section :   Macro Functions Declarations    */

#define TIMER0_ENABLE()                     (T0CONbits.TMR0ON = 1)
#define TIMER0_DISABLE()                    (T0CONbits.TMR0ON = 0)

#define TIMER0_PRESCALAR_ENABLE()           (T0CONbits.PSA = 0)
#define TIMER0_PRESCALAR_DISABLE()          (T0CONbits.PSA = 1)
#define TIMER0_SET_PRESCALAR(_PRESCALAR)    (T0CONbits.T0PS = _PRESCALAR)

#define TIMER0_INC_RISING_EDGE()            (T0CONbits.T0SE = 0)
#define TIMER0_INC_FALLING_EDGE()           (T0CONbits.T0SE = 1)

#define TIMER0_8BIT_MODE()                  (T0CONbits.T08BIT = 1)
#define TIMER0_16BIT_MODE()                 (T0CONbits.T08BIT = 0)

#define TIMER0_COUNTER_MODE()               (T0CONbits.T0CS = 1)
#define TIMER0_TIMER_MODE()                 (T0CONbits.T0CS = 0)


/*  Section :   Data Type Declarations    */

typedef enum
{
    TIMER0_PRESCALAR_DIV_BY_2 = 0,
    TIMER0_PRESCALAR_DIV_BY_4,
    TIMER0_PRESCALAR_DIV_BY_8,
    TIMER0_PRESCALAR_DIV_BY_16,
    TIMER0_PRESCALAR_DIV_BY_32,
    TIMER0_PRESCALAR_DIV_BY_64,
    TIMER0_PRESCALAR_DIV_BY_128,
    TIMER0_PRESCALAR_DIV_BY_256,
} Timer0_prescalar_t;


typedef struct
{
#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
    void (*interrupt_handler)(void);
    Interrupt_priority TMR0_interrupt_priority;
#endif
    Timer0_prescalar_t prescalar;
    uint16 preload_value;
    uint8 timer0_mode       :1;
    uint8 counter_edge      :1;
    uint8 prescalar_status  :1;
    uint8 register_size     :1;
    uint8                   :4;
} Timer0_t;


/*  Section :   Function Declarations    */

/**
 * @brief initializes timer0 module
 *
 * @param _timer0 pointer to timer0 module configurations @ref Timer0_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer0_init(const Timer0_t *_timer0);

/**
 * @brief deinitializes timer0 module
 *
 * @param _timer0 pointer to timer0 module configurations @ref Timer0_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer0_deinit(const Timer0_t *_timer0);

/**
 * @brief 
 * 
 * @param _timer0 pointer to timer0 module configurations @ref Timer0_t
 * @param _value  value to be written to Timer0 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action 
 */
Std_ReturnType Timer0_write(const Timer0_t *_timer0, uint16 _value);

/**
 * @brief 
 * 
 * @param _timer0 pointer to timer0 module configurations @ref Timer0_t
 * @param _value  pointer to value to be read from Timer0 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action 
 */
Std_ReturnType Timer0_read(const Timer0_t *_timer0, uint16 *_value);

#endif /* MCAL_TIMER0_H */
