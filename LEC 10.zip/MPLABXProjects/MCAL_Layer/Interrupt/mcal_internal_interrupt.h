/* 
 * File:   mcal_internal_interrupt.h
 * Author: AHMED BAKR
 *
 * Created on July 26, 2023, 1:46 AM
 */

#ifndef MCAL_INTERNAL_INTERRUPT_H
#define	MCAL_INTERNAL_INTERRUPT_H



/*  Section :   includes    */
#include "mcal_interrupt_cfg.h"
/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */
#if INTERRUPT_FEATURE_ENABLE == ADC_INTERRUPT_FEATURE_ENABLE

    #define ADC_INTERRUPT_ENABLE()          (PIE1bits.ADIE = 1)

    #define ADC_INTERRUPT_DISABLE()         (PIE1bits.ADIE = 0)

    #define ADC_INTERRUPT_CLEAR_FLAG()      (PIR1bits.ADIF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define ADC_INTERRUPT_PRIORITY_HIGH()   (IPR1bits.ADIP = INTERRUPT_HIGH_PRIORITY)

    #define ADC_INTERRUPT_PRIORITY_LOW()    (IPR1bits.ADIP = INTERRUPT_LOW_PRIORITY)

#endif

#endif

#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define TIMER0_INTERRUPT_ENABLE()           (INTCONbits.TMR0IE = 1)
    #define TIMER0_INTERRUPT_DISABLE()          (INTCONbits.TMR0IE = 0)
    #define TIMER0_INTERRUPT_FLAG_CLEAR()       (INTCONbits.TMR0IF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    #define TIMER0_INTERRUPT_PRIORITY_HIGH()    (INTCON2bits.TMR0IP = INTERRUPT_HIGH_PRIORITY)
    #define TIMER0_INTERRUPT_PRIORITY_LOW()     (INTCON2bits.TMR0IP = INTERRUPT_LOW_PRIORITY)
#endif

#endif

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif	/* MCAL_INTERNAL_INTERRUPT_H */

