/*
 * File:   hal_eeprom.h
 * Author: AHMED BAKR
 *
 * Created on July 27, 2023, 11:11 PM
 */
#include "hal_eeprom.h"

/**
 * @brief
 *
 * @param address Address of location in EEPROM
 * @param data  Pointer to data to return the value read from address in
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType EEPROM_read_data(uint16 address, uint8 *data)
{
    Std_ReturnType ret = E_OK;

    if (NULL == data)
    {
        ret = E_NOT_OK;
    }
    else
    {
        // Write on the EEPROM adress registers
        EEADRH = (uint8)((address >> 8) & 0x03);
        EEADR = (uint8)(address & 0xFF);

        // Select Access data EEPROM
        EECON1bits.EEPGD = EEPROM_MEMORY_ACCESS;
        EECON1bits.CFGS = ACESS_FLASH_OR_EEPROM;

        // Allow read cycle
        EECON1bits.RD = ALLOW_READ_CYCLE; // read takes 1 cycle
        NOP();  // it is preferred for high freq
        NOP();

        // Return data
        *data = EEDATA;
    }

    return ret;
}

/**
 * @brief
 *
 * @param address Address of location in EEPROM
 * @param data  Data to be written in EEPROM
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType EEPROM_write_data(uint16 address, uint8 data)
{
    Std_ReturnType ret = E_OK;

    // Read interrupt status
    uint8 global_interrupt_status = INTCONbits.GIE;

    // Write on the EEPROM adress registers
    EEADRH = (uint8)((address >> 8) & 0x03);
    EEADR = (uint8)(address & 0xFF);

    // Update Data Register
    EEDATA = data;

    // Select Access data EEPROM
    EECON1bits.EEPGD = EEPROM_MEMORY_ACCESS;
    EECON1bits.CFGS = ACESS_FLASH_OR_EEPROM;

    // Allow write cycle
    EECON1bits.WREN = ALLOW_WRITE_CYCLE;

    // Disable Global Interrupt

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    INTERRUPT_GLOBAL_HIGH_DISABLE();
#else
    INTERRUPT_GLOBAL_DISABLE();
#endif

    // Write the key sequence
    EECON2 = 0x55;
    EECON2 = 0xAA;

    // Enable Writing
    EECON1bits.WR = EEPROM_WRITE_ERASE_INIT;

    // Wait for erase-write cycle to be finished
    while (!(EEPROM_WRITE_ERASE_FINISH == EECON1bits.WR));

    // Inhibit write cycle
    EECON1bits.WREN = INHIBIT_WRITE_CYCLE;

    // Restore global interrupt status;
    INTCONbits.GIE = global_interrupt_status;

    return ret;
}
