/* 
 * File:   hal_eeprom.h
 * Author: AHMED BAKR
 *
 * Created on July 27, 2023, 11:11 PM
 */

#ifndef HAL_EEPROM_H
#define	HAL_EEPROM_H

/*----------------- SEC: Includes ----------------------*/
#include "../Interrupt/mcal_internal_interrupt.h"
#include "../../pic18f4620.h"
#include "../mcal_std_types.h"
/*------------------ SEC: MACROS DEF ----------------------*/

#define FLASH_PROGRAM_ACCESS    1
#define EEPROM_MEMORY_ACCESS    0

#define ACCESS_CONFIG_REGS      1
#define ACESS_FLASH_OR_EEPROM   0

#define ALLOW_WRITE_CYCLE       1
#define INHIBIT_WRITE_CYCLE     0

#define ALLOW_READ_CYCLE       1
#define INHIBIT_READ_CYCLE     0

#define EEPROM_WRITE_ERASE_INIT     1
#define EEPROM_WRITE_ERASE_FINISH   1


/*------------------ SEC: MACRO FUNC ----------------------*/

/*------------------ SEC: USER DEFINED DATA TYPES ----------------------*/

/*------------------ SEC: SOFTWARE INTERfACES ----------------------*/

/**
 * @brief 
 * 
 * @param address Address of location in EEPROM
 * @param data  Pointer to data to return the value read from address in
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType EEPROM_read_data(uint16 address, uint8 *data);

/**
 * @brief 
 * 
 * @param address Address of location in EEPROM
 * @param data  Data to be written in EEPROM
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action 
 */
Std_ReturnType EEPROM_write_data(uint16 address, uint8 data);

#endif	/* HAL_EEPROM_H */

