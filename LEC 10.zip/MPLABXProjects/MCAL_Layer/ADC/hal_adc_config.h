/*
 * File:   hal_adc_config.h
 * Author: AHMED BAKR
 *
 * Created on July 30, 2023, 12:46 AM
 */

#ifndef HAL_ADC_CONFIG_H
#define HAL_ADC_CONFIG_H

/*  Section :   includes    */

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif /* HAL_ADC_CONFIG_H */
