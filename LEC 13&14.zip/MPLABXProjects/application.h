/*
 * File:   application.h
 * Author: AHMED BAKR
 *
 * Created on July 18, 2023, 4:42 PM
 */

#ifndef APPLICATION_H
#define APPLICATION_H

/*  Section :   includes    */
#include "ECU_Layer/ecu_layer_init.h"
#include "MCAL_Layer/Interrupt/mcal_external_interrupt.h"
#include "MCAL_Layer/EEPROM/hal_eeprom.h"
#include "MCAL_Layer/ADC/hal_adc.h"
#include "MCAL_Layer/Timer0/hal_timer0.h"
#include "MCAL_Layer/Timer1/hal_timer1.h"
#include "MCAL_Layer/Timer2/hal_timer2.h"
#include "MCAL_Layer/CCP1/hal_ccp1.h"

extern LCD_4bit_t lcd1;
extern LCD_8bit_t lcd2;


/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

void app_init(void);

#endif /* APPLICATION_H */
