#include "hal_usart.h"

#if EUSART_TX_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*EUSART_TX_interrupt_handler)(void) = NULL;
#endif

#if EUSART_RX_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*EUSART_RX_interrupt_handler)(void) = NULL;
static void (*EUSART_OERR_interrupt_handler)(void) = NULL;
static void (*EUSART_FERR_interrupt_handler)(void) = NULL;
#endif

static void EUSART_ASYNC_Baud_Rate_Calculation(const USART_t *_usart);
static void EUSART_TX_init(const USART_t *_usart);
static void EUSART_RX_init(const USART_t *_usart);

Std_ReturnType EUSART_ASYNC_init(const USART_t *_usart)
{
    Std_ReturnType ret = E_OK;
    RCSTAbits.SPEN = EUSART_MODULE_DISABLE;
    if (NULL == _usart)
    {
        ret = E_NOT_OK;
    }
    else
    {
        EUSART_ASYNC_Baud_Rate_Calculation(_usart);

        TRISCbits.RC6 = INPUT;
        TRISCbits.RC7 = INPUT;

        EUSART_TX_init(_usart);
        EUSART_RX_init(_usart);

        RCSTAbits.SPEN = EUSART_MODULE_ENABLE;
    }

    return ret;
}

Std_ReturnType EUSART_ASYNC_deinit(const USART_t *_usart)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _usart)
    {
        ret = E_NOT_OK;
    }
    else
    {
    }

    return ret;
}

Std_ReturnType EUSART_ASYNC_WriteByteBlocking(const USART_t *_usart, uint8 _value)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _usart)
    {
        ret = E_NOT_OK;
    }
    else
    {
        while (!TXSTAbits.TRMT)
            ;
        TXREG = _value;
    }

    return ret;
}

Std_ReturnType EUSART_ASYNC_WriteStringBlocking(const USART_t *_usart, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _usart)
    {
        ret = E_NOT_OK;
    }
    else
    {
        while (*str)
        {
            while (!TXSTAbits.TRMT)
                ;
            TXREG = *(str++);
        }
    }

    return ret;
}

Std_ReturnType EUSART_ASYNC_ReadByteBlocking(const USART_t *_usart, uint8 *_value)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == _usart) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        while (!PIR1bits.RCIF)
            ;
        *_value = RCREG;
    }

    return ret;
}

Std_ReturnType EUSART_ASYNC_ReadByteNonBlocking(const USART_t *_usart, uint8 *_value)
{
    Std_ReturnType ret = E_NOT_OK;
    if ((NULL == _usart) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        if (PIR1bits.RCIF == 1)
        {
            *_value = RCREG;
            ret = E_OK;
        }
        else if (PIR1bits.RCIF == 0)
        {
            ret = E_NOT_OK;
        }
        else
        { /* Nothing */
        }
    }
    return ret;
}

static void EUSART_ASYNC_Baud_Rate_Calculation(const USART_t *_usart)
{
    float baud_rate_temp = 0;

    switch (_usart->baudrate_gen_gonfig)
    {
    case BAUDRATE_ASYN_8BIT_lOW_SPEED:
        TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
        TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_LOW_SPEED;
        BAUDCONbits.BRG16 = EUSART_08BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 64) - 1;
        break;

    case BAUDRATE_ASYN_8BIT_HIGH_SPEED:
        TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
        TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_HIGH_SPEED;
        BAUDCONbits.BRG16 = EUSART_08BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 16) - 1;

        break;

    case BAUDRATE_ASYN_16BIT_lOW_SPEED:
        TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
        TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_LOW_SPEED;
        BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 16) - 1;

        break;

    case BAUDRATE_ASYN_16BIT_HIGH_SPEED:
        TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
        TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_HIGH_SPEED;
        BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 16) - 1;

        break;

    case BAUDRATE_SYN_8BIT:
        TXSTAbits.SYNC = EUSART_SYNCHRONOUS_MODE;
        BAUDCONbits.BRG16 = EUSART_08BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 4) - 1;

        break;

    case BAUDRATE_SYN_16BIT:
        TXSTAbits.SYNC = EUSART_SYNCHRONOUS_MODE;
        BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;

        baud_rate_temp = ((_XTAL_FREQ / (float)_usart->baudrate) / 4) - 1;

        break;

    default:
        break;
    }
    SPBRG = (uint8)((uint32)baud_rate_temp);
    SPBRGH = (uint8)((uint32)baud_rate_temp >> 8);
}

static void EUSART_TX_init(const USART_t *_usart)
{
    if (EUSART_ASYNCHRONOUS_TX_ENABLE == _usart->usart_tx_cfg.usart_tx_enable)
    {
        TXSTAbits.TXEN = EUSART_ASYNCHRONOUS_TX_ENABLE;
        EUSART_TX_interrupt_handler = _usart->EUSART_TxDefaultInterruptHandler;
        if (EUSART_ASYNCHRONOUS_INTERRUPT_TX_ENABLE == _usart->usart_tx_cfg.usart_tx_enable)
        {
            PIE1bits.TXIE = EUSART_ASYNCHRONOUS_INTERRUPT_TX_ENABLE;
#if EUSART_TX_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            INTERRUPT_GLOBAL_LOW_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
            EUSART_TX_InterruptEnable();

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
            if (INTERRUPT_HIGH_PRIORITY == _usart->usart_tx_interrupt_enable)
            {
                EUSART_TX_HighPrioritySet();
            }
            else if (INTERRUPT_LOW_PRIORITY == _usart->usart_tx_interrupt_enable)
            {
                EUSART_TX_LowPrioritySet();
            }
            else
            { /* Nothing */
            }

#endif

#endif
        }
        else if (EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE == _usart->usart_tx_cfg.usart_tx_enable)
        {
            PIE1bits.TXIE = EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE;
        }
        else
        { /* Nothing */
        }

        if (EUSART_ASYNCHRONOUS_9Bit_TX_ENABLE == _usart->usart_tx_cfg.usart_tx_9bit_enable)
        {
            TXSTAbits.TX9 = EUSART_ASYNCHRONOUS_9Bit_TX_ENABLE;
        }
        else if (EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE == _usart->usart_tx_cfg.usart_tx_9bit_enable)
        {
            TXSTAbits.TX9 = EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE;
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

static void EUSART_RX_init(const USART_t *_usart)
{
    if (EUSART_ASYNCHRONOUS_RX_ENABLE == _usart->usart_rx_cfg.usart_rx_enable)
    {
        RCSTAbits.CREN = EUSART_ASYNCHRONOUS_RX_ENABLE;

        EUSART_TX_interrupt_handler = _usart->EUSART_RxDefaultInterruptHandler;
        EUSART_OERR_interrupt_handler = _usart->EUSART_OverrunErrorHandler;
        EUSART_FERR_interrupt_handler = _usart->EUSART_FramingErrorHandler;

        if (EUSART_ASYNCHRONOUS_INTERRUPT_RX_ENABLE == _usart->usart_rx_cfg.usart_rx_enable)
        {
            PIE1bits.RCIE = EUSART_ASYNCHRONOUS_INTERRUPT_RX_ENABLE;
#if EUSART_RX_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            INTERRUPT_GLOBAL_LOW_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
            EUSART_RX_InterruptEnable();

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
            if (INTERRUPT_HIGH_PRIORITY == _usart->usart_rx_interrupt_enable)
            {
                EUSART_RX_HighPrioritySet();
            }
            else if (INTERRUPT_LOW_PRIORITY == _usart->usart_rx_interrupt_enable)
            {
                EUSART_RX_LowPrioritySet();
            }
            else
            { /* Nothing */
            }

#endif

#endif
        }
        else if (EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE == _usart->usart_rx_cfg.usart_rx_enable)
        {
            PIE1bits.RCIE = EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE;
        }
        else
        { /* Nothing */
        }

        if (EUSART_ASYNCHRONOUS_9Bit_RX_ENABLE == _usart->usart_rx_cfg.usart_rx_9bit_enable)
        {
            RCSTAbits.RC9 = EUSART_ASYNCHRONOUS_9Bit_RX_ENABLE;
        }
        else if (EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE == _usart->usart_rx_cfg.usart_rx_9bit_enable)
        {
            TXSTAbits.TX9 = EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE;
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

void EUSART_TX_ISR(void)
{
    if (EUSART_TX_interrupt_handler)
    {
        EUSART_TX_interrupt_handler();
    }
    else
    { /*Nothing*/
    }
}

void EUSART_RX_ISR(void)
{
    if (EUSART_RX_interrupt_handler)
    {
        EUSART_RX_interrupt_handler();
    }
    else { /*Nothing*/ }

    if (EUSART_FERR_interrupt_handler)
    {
        EUSART_FERR_interrupt_handler();
    }
    else { /*Nothing*/ }

    if (EUSART_OERR_interrupt_handler)
    {
        EUSART_OERR_interrupt_handler();
    }
    else { /*Nothing*/ }
}
