#ifndef HAL_USART_H
#define HAL_USART_H

/********************************* Includes ******************************************/

#include "hal_usart_cfg.h"
#include "../../pic18f4620.h"
#include "../Interrupt/mcal_internal_interrupt.h"
#include "../GPIO/hal_gpio.h"
#include "../mcal_std_types.h"

/********************************** Macros *******************************************/
/* Enable / Disable EUSART Module */
#define EUSART_MODULE_ENABLE    1
#define EUSART_MODULE_DISABLE   0

/* Selecting EUSART Working Mode */
#define EUSART_SYNCHRONOUS_MODE 1
#define EUSART_ASYNCHRONOUS_MODE 0
/* Baud Rate Generator Asynchronous Speed Mode */
#define EUSART_ASYNCHRONOUS_HIGH_SPEED 1
#define EUSART_ASYNCHRONOUS_LOW_SPEED 0
/* Baud Rate Generator Register Size */
#define EUSART_16BIT_BAUDRATE_GEN 1
#define EUSART_08BIT_BAUDRATE_GEN 0

/* EUSART Transmit Enable */
#define EUSART_ASYNCHRONOUS_TX_ENABLE 1
#define EUSART_ASYNCHRONOUS_TX_DISABLE 0
/* EUSART Transmit Interrupt Enable */
#define EUSART_ASYNCHRONOUS_INTERRUPT_TX_ENABLE 1
#define EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE 0
/* EUSART 9-Bit Transmit Enable */
#define EUSART_ASYNCHRONOUS_9Bit_TX_ENABLE 1
#define EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE 0

/* EUSART Receiver Enable */
#define EUSART_ASYNCHRONOUS_RX_ENABLE 1
#define EUSART_ASYNCHRONOUS_RX_DISABLE 0
/* EUSART Receiver Interrupt Enable */
#define EUSART_ASYNCHRONOUS_INTERRUPT_RX_ENABLE 1
#define EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE 0
/* EUSART 9-Bit Receiver Enable */
#define EUSART_ASYNCHRONOUS_9Bit_RX_ENABLE 1
#define EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE 0
/* EUSART Framing Error */
#define EUSART_FRAMING_ERROR_DETECTED 1
#define EUSART_FRAMING_ERROR_CLEARED 0
/* EUSART Overrun Error */
#define EUSART_OVERRUN_ERROR_DETECTED 1
#define EUSART_OVERRUN_ERROR_CLEARED 0

/****************************** Macro Functions **************************************/

/************************** User Defined Data Types **********************************/
typedef enum
{
    BAUDRATE_ASYN_8BIT_lOW_SPEED,
    BAUDRATE_ASYN_8BIT_HIGH_SPEED,
    BAUDRATE_ASYN_16BIT_lOW_SPEED,
    BAUDRATE_ASYN_16BIT_HIGH_SPEED,
    BAUDRATE_SYN_8BIT,
    BAUDRATE_SYN_16BIT
} Baudrate_gen_t;

typedef struct
{
    Interrupt_priority usart_tx_int_priority;
    uint8 usart_tx_enable : 1;
    uint8 usart_tx_interrupt_enable : 1;
    uint8 usart_tx_9bit_enable : 1;
    uint8 usart_tx_reserved : 5;
} USART_tx_cfg_t;

typedef struct
{
    Interrupt_priority usart_rx_int_priority;
    uint8 usart_rx_enable : 1;
    uint8 usart_rx_interrupt_enable : 1;
    uint8 usart_rx_9bit_enable : 1;
    uint8 usart_rx_reserved : 5;
} USART_rx_cfg_t;

typedef union
{
    struct
    {
        uint8 usart_tx_reserved : 6;
        uint8 usart_ferr : 1;
        uint8 usart_oerr : 1;
    };
    uint8 status;
} USART_error_status_t;

typedef struct
{
    uint32 baudrate;
    Baudrate_gen_t baudrate_gen_gonfig;
    USART_tx_cfg_t usart_tx_cfg;
    USART_rx_cfg_t usart_rx_cfg;
    USART_error_status_t error_status;
    void (*EUSART_TxDefaultInterruptHandler)(void);
    void (*EUSART_RxDefaultInterruptHandler)(void);
    void (*EUSART_FramingErrorHandler)(void);
    void (*EUSART_OverrunErrorHandler)(void);
} USART_t;

/**************************** Software Interfaces ************************************/

/**
 * @brief 
 * 
 * @param _usart 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_init(const USART_t *_usart);

/**
 * @brief 
 * 
 * @param _usart 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_deinit(const USART_t *_usart);

/**
 * @brief 
 * 
 * @param _usart 
 * @param _value 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_WriteByteBlocking(const USART_t *_usart, uint8 _value);

/**
 * @brief 
 * 
 * @param _usart 
 * @param str 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_WriteStringBlocking(const USART_t *_usart, uint8 *str);

/**
 * @brief 
 * 
 * @param _usart 
 * @param _value 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_ReadByteBlocking(const USART_t *_usart, uint8 *_value);

/**
 * @brief 
 * 
 * @param _usart 
 * @param _value 
 * @return Std_ReturnType 
 */
Std_ReturnType EUSART_ASYNC_ReadByteNonBlocking(const USART_t *_usart, uint8 *_value);



#endif /* HAL_USART_H */