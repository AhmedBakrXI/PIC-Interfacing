#include "hal_adc.h"

#if INTERRUPT_FEATURE_ENABLE == ADC_INTERRUPT_FEATURE_ENABLE
static void (*ADC_interrupt_handler)(void) = NULL;
#endif

static inline void ADC_input_channel_port_config(ADC_channel_select_t channel);
static inline void ADC_select_result_format(const ADC_t *_adc);
static inline void ADC_select_voltage_reference(const ADC_t *_adc);
/**
 * @brief
 *
 * @param _adc
 * @return Std_ReturnType
 */
Std_ReturnType ADC_init(const ADC_t *_adc)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _adc)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ADC_DISABLE();

        ADCON0bits.CHS = _adc->channel;               // Select AN Channel
        ADCON2bits.ACQT = _adc->acquisition_time;     // Select acquisition time
        ADCON2bits.ADCS = _adc->conversion_clk;       // Select conversion clock
        ADC_input_channel_port_config(_adc->channel); // Configure pin as input
/*
 * Configure the interrupt if desired
 */
#if ADC_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GLOBAL_HIGH_ENABLE();
        INTERRUPT_GLOBAL_LOW_ENABLE();
        INTERRUPT_PERIPHERAL_ENABLE();
        ADC_INTERRUPT_ENABLE();
        ADC_INTERRUPT_CLEAR_FLAG();
        ADC_interrupt_handler = _adc->ADC_interrupt_handler;

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        if (INTERRUPT_HIGH_PRIORITY == _adc->priority)
        {
            ADC_INTERRUPT_PRIORITY_HIGH();
        }
        else if (INTERRUPT_LOW_PRIORITY == _adc->priority)
        {
            ADC_INTERRUPT_PRIORITY_LOW();
        }
        else
        { /* Nothing */
        }

#endif

#endif

        ADC_select_result_format(_adc);
        ADC_select_voltage_reference(_adc);

        ADC_ENABLE();
        ADC_START_CONVERTION();

        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @return Std_ReturnType
 */
Std_ReturnType ADC_deinit(const ADC_t *_adc)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _adc)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ADC_DISABLE();
// Disable Interrupts
// ??
#if ADC_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

#endif
        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @param channel
 * @return Std_ReturnType
 */
Std_ReturnType ADC_select_channel(const ADC_t *_adc, ADC_channel_select_t channel)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _adc)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ADCON0bits.CHS = channel;
        ADC_input_channel_port_config(channel);
        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @return Std_ReturnType
 */
Std_ReturnType ADC_start_conversion(const ADC_t *_adc)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _adc)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ADC_START_CONVERTION();
        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @param status
 * @return Std_ReturnType
 */
Std_ReturnType ADC_conversion_status(const ADC_t *_adc, uint8 *status)
{
    Std_ReturnType ret = E_NOT_OK;

    if ((NULL == _adc) || (NULL == status))
    {
        ret = E_NOT_OK;
    }
    else
    {
        *status = ADC_CONVERSION_STATUS();
        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @param result
 * @return Std_ReturnType
 */
Std_ReturnType ADC_get_conversion_result(const ADC_t *_adc, uint16 *result)
{
    Std_ReturnType ret = E_NOT_OK;

    if ((NULL == _adc) || (NULL == result))
    {
        ret = E_NOT_OK;
    }
    else
    {
        if (ADC_RESULT_LEFT == _adc->result_format)
        {
            *result = (uint16)((ADRESH << 8) + ADRESL);
        }
        else
        {
            *result = (uint16)(((ADRESH << 8) + ADRESL) >> 6);
        }
        ret = E_OK;
    }

    return ret;
}

/**
 * @brief
 *
 * @param _adc
 * @param channel
 * @param result
 * @return Std_ReturnType
 */
Std_ReturnType ADC_get_conversion_blocking(const ADC_t *_adc, ADC_channel_select_t channel, uint16 *result)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == _adc) || (NULL == result))
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = ADC_select_channel(_adc, channel);
        ret &= ADC_start_conversion(_adc);
        while (ADCON0bits.GO_nDONE);
        ret &= ADC_get_conversion_result(_adc, result);
    }

    return ret;
}

Std_ReturnType ADC_start_conversion_interrupt(const ADC_t *_adc, ADC_channel_select_t channel)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _adc)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = ADC_select_channel(_adc, channel);
        ret &= ADC_start_conversion(_adc);
    }

    return ret;
}

static inline void ADC_input_channel_port_config(ADC_channel_select_t channel)
{
    switch (channel)
    {
    case ADC_CHANNEL_AN0:
        SET_BIT(TRISA, _TRISA_RA0_POSN);
        break;
    case ADC_CHANNEL_AN1:
        SET_BIT(TRISA, _TRISA_RA1_POSN);
        break;
    case ADC_CHANNEL_AN2:
        SET_BIT(TRISA, _TRISA_RA2_POSN);
        break;
    case ADC_CHANNEL_AN3:
        SET_BIT(TRISA, _TRISA_RA3_POSN);
        break;
    case ADC_CHANNEL_AN4:
        SET_BIT(TRISA, _TRISA_RA5_POSN);
        break;
    case ADC_CHANNEL_AN5:
        SET_BIT(TRISE, _TRISE_RE0_POSN);
        break;
    case ADC_CHANNEL_AN6:
        SET_BIT(TRISE, _TRISE_RE1_POSN);
        break;
    case ADC_CHANNEL_AN7:
        SET_BIT(TRISE, _TRISE_RE2_POSN);
        break;
    case ADC_CHANNEL_AN8:
        SET_BIT(TRISB, _TRISB_RB2_POSN);
        break;
    case ADC_CHANNEL_AN9:
        SET_BIT(TRISB, _TRISB_RB3_POSN);
        break;
    case ADC_CHANNEL_AN10:
        SET_BIT(TRISB, _TRISB_RB1_POSN);
        break;
    case ADC_CHANNEL_AN11:
        SET_BIT(TRISB, _TRISB_RB4_POSN);
        break;
    case ADC_CHANNEL_AN12:
        SET_BIT(TRISB, _TRISB_RB0_POSN);
        break;
    default:
        break;
    }
}

static inline void ADC_select_result_format(const ADC_t *_adc)
{
    if (ADC_RESULT_LEFT == _adc->result_format)
    {
        ADC_RESULT_LEFT_FORMAT();
    }
    else
    {
        ADC_RESULT_RIGHT_FORMAT();
    }
}

static inline void ADC_select_voltage_reference(const ADC_t *_adc)
{
    if (ADC_VOLTAGE_REFERENCE_ENABLED == _adc->voltage_ref)
    {
        ADC_ENABLE_VOLTAGE_REFERENCE();
    }
    else
    {
        ADC_DISABLE_VOLTAGE_REFERENCE();
    }
}

void ADC_ISR(void)
{
    ADC_INTERRUPT_CLEAR_FLAG();
    if (ADC_interrupt_handler)
    {
        ADC_interrupt_handler();
    }
    else
    { /* Nothing */
    }
}
