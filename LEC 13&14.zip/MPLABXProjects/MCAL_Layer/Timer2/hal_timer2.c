#include "hal_timer2.h"
#if TIMER1_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static volatile void (*TMR2_interrupt_handler)(void) = NULL;
#endif
static volatile uint8 timer2_preload = ZERO_INIT;


/**
 * @brief initializes timer2 module
 *
 * @param _timer pointer to timer2 module configurations @ref Timer2_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer2_init(const Timer2_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TIMER2_MODULE_DISABLE();

        TIMER2_PRESCALER_SELECT(_timer->timer2_prescaler_value);
        TIMER2_POSTSCALER_SELECT(_timer->timer2_postscaler_value);

        TMR2 = _timer->timer2_preload_value;
        timer2_preload = _timer->timer2_preload_value;

#if TIMER2_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GLOBAL_ENABLE();
        INTERRUPT_PERIPHERAL_ENABLE();
        TIMER2_INTERRUPT_ENABLE();
        TIMER2_INTERRUPT_FLAG_CLEAR();
        TMR2_interrupt_handler = _timer->TMR2_InterruptHandler;
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_FEATURE_ENABLE();
        if (INTERRUPT_HIGH_PRIORITY == _timer->priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            TIMER2_INTERRUPT_PRIORITY_HIGH();
        }
        else if (INTERRUPT_LOW_PRIORITY == _timer->priority)
        {
            INTERRUPT_GLOBAL_LOW_ENABLE();
            TIMER2_INTERRUPT_PRIORITY_LOW();
        }
        else
        {
            /* NOTHING */
        }
#endif
#endif

        TIMER2_MODULE_ENABLE();
    }
    return ret;
}

/**
 * @brief deinitializes timer2 module
 *
 * @param _timer pointer to timer2 module configurations @ref Timer2_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer2_deinit(const Timer2_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {        // Disable timer0 module
        TIMER2_MODULE_DISABLE();
#if TIMER2_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER2_INTERRUPT_DISABLE();
#endif
    }
    return ret;
}

/**
 * @brief
 *
 * @param _timer  pointer to timer0 module configurations @ref Timer1_t
 * @param _value  value to be written to Timer0 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer2_write(const Timer2_t *_timer, uint8 _value)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TMR2 = _value;
    }
    return ret;
}

/**
 * @brief
 *
 * @param _timer  pointer to timer1 module configurations @ref Timer1_t
 * @param _value  pointer to value to be read from Timer2 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer2_read(const Timer2_t *_timer, uint8 *_value)
{
    Std_ReturnType ret = E_OK;
    uint8 l_tmr1h = ZERO_INIT, l_tmr1l = ZERO_INIT;

    if ((NULL == _timer) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        *_value = TMR2;
    }
    return ret;
}

void TMR2_ISR(void){
    TIMER2_INTERRUPT_FLAG_CLEAR();     /* Clear the interrupt flag */
    TMR2 = timer2_preload;   /* Initialize the pre-loaded value again */
    if(TMR2_interrupt_handler){
        TMR2_interrupt_handler();     /* Call the callback function */
    }
}