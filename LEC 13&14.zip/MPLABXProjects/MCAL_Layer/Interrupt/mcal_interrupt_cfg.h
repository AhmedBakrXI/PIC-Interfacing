/*
 * File:   mcal_interrupt_cfg.h
 * Author: AHMED BAKR
 *
 * Created on July 26, 2023, 1:45 AM
 */

#ifndef MCAL_INTERRUPT_CFG_H
#define MCAL_INTERRUPT_CFG_H
/*  Section :   includes    */
#include "../../pic18f4620.h"
#include "../mcal_std_types.h"
#include "mcal_interrupt_gen_cfg.h"
#include "../GPIO/hal_gpio.h"
/*  Section :   Macro Declarations    */

#define INTERRUPT_ENABLE 1
#define INTERRUPT_DISABLE 0

#define INTERRUPT_OCCUR 1
#define INTERRUPT_NOT_OCCUR 0

#define INTERRUPT_PRIORITY_ENABLE 1
#define INTERRUPT_PRIORITY_DISABLE 0

/*  Section :   Macro Functions Declarations    */

// #if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

#define INTERRUPT_GLOBAL_HIGH_ENABLE() (INTCONbits.GIEH = 1)

#define INTERRUPT_GLOBAL_HIGH_DISABLE() (INTCONbits.GIEH = 0)

#define INTERRUPT_GLOBAL_LOW_ENABLE() (INTCONbits.GIEL = 1)

#define INTERRUPT_GLOBAL_LOW_DISABLE() (INTCONbits.GIEL = 0)

#define INTERRUPT_PRIORITY_FEATURE_ENABLE() (RCONbits.IPEN = 1)

#define INTERRUPT_PRIORITY_FEATURE_DISABLE() (RCONbits.IPEN = 0)

#define INTERRUPT_PERIPHERAL_ENABLE() (INTCONbits.PEIE = 1)

#define INTERRUPT_PERIPHERAL_DISABLE() (INTCONbits.PEIE = 0)


// #else /*    No Priority Levels      */

#define INTERRUPT_GLOBAL_ENABLE() (INTCONbits.GIE = 1)

#define INTERRUPT_GLOBAL_DISABLE() (INTCONbits.GIE = 0)

#define INTERRUPT_PERIPHERAL_ENABLE() (INTCONbits.PEIE = 1)

#define INTERRUPT_PERIPHERAL_DISABLE() (INTCONbits.PEIE = 0)

// #endif
/*  Section :   Data Type Declarations    */

typedef enum
{
    INTERRUPT_LOW_PRIORITY = 0,
    INTERRUPT_HIGH_PRIORITY,
} Interrupt_priority;

/*  Section :   Function Declarations    */

#endif /* MCAL_INTERRUPT_CFG_H */
