/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"
#include "MCAL_Layer/USART/hal_usart.h"

void usart_module_init(void)
{
    USART_t usart;
    usart.baudrate = 9600;
    usart.baudrate_gen_gonfig = BAUDRATE_ASYN_16BIT_lOW_SPEED;

    usart.usart_tx_cfg.usart_tx_enable = EUSART_ASYNCHRONOUS_TX_ENABLE;
    usart.usart_tx_cfg.usart_tx_9bit_enable = EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE;
    usart.usart_tx_cfg.usart_tx_interrupt_enable = EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE;
    usart.usart_tx_cfg.usart_tx_int_priority = INTERRUPT_LOW_PRIORITY;

    usart.usart_rx_cfg.usart_rx_enable = EUSART_ASYNCHRONOUS_RX_ENABLE;
    usart.usart_rx_cfg.usart_rx_9bit_enable = EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE;
    usart.usart_rx_cfg.usart_rx_interrupt_enable = EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE;
    usart.usart_rx_cfg.usart_rx_int_priority = INTERRUPT_LOW_PRIORITY;

    usart.EUSART_FramingErrorHandler = NULL;
    usart.EUSART_OverrunErrorHandler = NULL;
    usart.EUSART_RxDefaultInterruptHandler = NULL;
    usart.EUSART_TxDefaultInterruptHandler = NULL;

    EUSART_ASYNC_init(&usart);

    /******************* Write Byte Test *******************/
    // int i = 0;
    // while (1)
    // {
    //     EUSART_ASYNC_WriteByteBlocking(&usart, 'a');
    //     i++;
    //     if (10 == i)
    //     {
    //         EUSART_ASYNC_WriteByteBlocking(&usart, '\n');
    //     }
    //     __delay_ms(200);
    // }

    /******************* Read Byte Test *******************/
    led_t led = {
        .port = PORTC_INDEX,
        .pin = PIN0,
        .status = LED_OFF,
    };

    led_initialize(&led);

    uint8 readByte;
    // while (1)
    // {
    //     EUSART_ASYNC_ReadByteBlocking(&usart, &readByte);
    //     if ('a' == readByte)
    //     {
    //         led_turn_on(&led);
    //     }
    //     else if ('b' == readByte)
    //     {
    //         led_turn_off(&led);
    //     }
    //     else{/* Nothing */}
    // }

    EUSART_ASYNC_WriteStringBlocking(&usart, "Hello, World!\r");
    EUSART_ASYNC_WriteStringBlocking(&usart, "I am NOT OK\r");
    EUSART_ASYNC_WriteStringBlocking(&usart, "Can you help me?! Y/N \r");

    while (1)
    {
        // EUSART_ASYNC_ReadByteBlocking(&usart, &readByte);
        EUSART_ASYNC_ReadByteNonBlocking(&usart, &readByte);
        if (('Y' == readByte) || ('y' == readByte))
        {
            led_turn_on(&led);
            EUSART_ASYNC_WriteStringBlocking(&usart, "\rThank you :-)\r");
            break;
        }
        else if (('N' == readByte) || ('n' == readByte))
        {
            led_turn_off(&led);
            EUSART_ASYNC_WriteStringBlocking(&usart, "\rThank you :-(\r");
            break;
        }
        else
        { /* Nothing */
        }
    }
}

int main()
{
    usart_module_init();

    while (1)
        ;
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt

Ahmed Mohammed Bakr     27July2023      Task-12 build mcal EEPROM interrupt

Ahmed Mohammed Bakr     30July2023      Task-13 build mcal ADC

Ahmed Mohammed Bakr     2Aug2023        Task-14 build Timer0 driver

Ahmed Mohammed Bakr     2Aug2023        Task-15 build Timer1 driver

Ahmed Mohammed Bakr     2Aug2023        Task-16 build Timer2 driver

Ahmed Mohammed Bakr     2Aug2023        Task-17 build Timer3 driver

Ahmed Mohammed Bakr     2Aug2023        Task-18 build CCP1 driver

Ahmed Mohammed Bakr     10Aug2023       Task-19 build USART driver

******************************************************************* */
