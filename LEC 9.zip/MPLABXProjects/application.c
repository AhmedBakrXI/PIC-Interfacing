/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

void handler(void);

uint16 result;

ADC_t adc1 = {
    .acquisition_time = ADC_0_TAD,
    .channel = ADC_CHANNEL_AN0,
    .conversion_clk = ADC_CONVERSION_CLOCK_FOSC_DIV_FRC,
    .result_format = ADC_RESULT_RIGHT,
    .voltage_ref = ADC_VOLTAGE_REFERENCE_DISABLED,
    .ADC_interrupt_handler = handler,
    .priority = INTERRUPT_HIGH_PRIORITY,
};

Std_ReturnType ret = E_NOT_OK;
char str[6];
uint8 value;

int main()
{
    app_init();

    ADC_init(&adc1);
    lcd_4bit_send_string(&lcd1, "Voltage On AN0: ");
    lcd_4bit_send_string_pos(&lcd1, " Volt", ROW2, 13);
     

    while (1)
    {
        ADC_start_conversion_interrupt(&adc1, ADC_CHANNEL_AN0);
    //    ADC_get_conversion_blocking(&adc1, ADC_CHANNEL_AN0, &result);
        // ADC_get_conversion_result(&adc1, &result);
        convert_short_to_str(result, str);
        lcd_4bit_send_string_pos(&lcd1, str, ROW2, 10);
    }

    return (EXIT_SUCCESS);
}

void handler(void)
{
    ADC_get_conversion_result(&adc1, &result);
}

void app_init(void)
{
    ecu_layer_init();
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt

Ahmed Mohammed Bakr     27July2023      Task-12 build mcal EEPROM interrupt

Ahmed Mohammed Bakr     30July2023      Task-13 build mcal ADC

******************************************************************* */
