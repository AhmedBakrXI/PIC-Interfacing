#include "mcal_interrupt_manager.h"

static volatile uint8 RB4_Flag = 1, RB5_Flag = 1, RB6_Flag = 1, RB7_Flag = 1;

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
void __interrupt() InterruptManagerHigh(void)
{
    if ((INTERRUPT_ENABLE == INTCONbits.INT0IE) && (INTERRUPT_OCCUR == INTCONbits.INT0IF))
    {
        INT0_ISR();
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCON3bits.INT1IE) && (INTERRUPT_OCCUR == INTCON3bits.INT1IF))
    {
        INT1_ISR();
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCON3bits.INT2IE) && (INTERRUPT_OCCUR == INTCON3bits.INT2IF))
    {
        INT2_ISR();
    }
    else
    { /* Nothing */
    }

    /******************************     ON CHANGE PORT B    **************************************/
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB4) && (RB4_Flag == 1))
    {
        RB4_Flag = 0;
        RB4_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB4) && (RB4_Flag == 0))
    {
        RB4_Flag = 1;
        RB4_ISR(0);
    }
    else
    { /* Nothing */
    }
    
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB5) && (RB5_Flag == 1))
    {
        RB5_Flag = 0;
        RB5_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB5) && (RB5_Flag == 0))
    {
        RB5_Flag = 1;
        RB5_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB6) && (RB6_Flag == 1))
    {
        RB6_Flag = 0;
        RB6_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB6) && (RB6_Flag == 0))
    {
        RB6_Flag = 0;
        RB6_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB7) && (RB7_Flag == 1))
    {
        RB7_Flag = 0;
        RB7_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB7) && (RB7_Flag == 0))
    {
        RB7_Flag = 1;
        RB7_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == PIE1bits.ADIE) && (INTERRUPT_OCCUR == PIR1bits.ADIF))
    {
        ADC_ISR();
    }
}

void __interrupt(low_priority) InterruptManagerLow(void)
{
    if ((INTERRUPT_ENABLE == INTCON3bits.INT1IE) && (INTERRUPT_OCCUR == INTCON3bits.INT1IF))
    {
        INT1_ISR();
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCON3bits.INT2IE) && (INTERRUPT_OCCUR == INTCON3bits.INT2IF))
    {
        INT2_ISR();
    }
    else
    { /* Nothing */
    }

      /******************************     ON CHANGE PORT B    **************************************/
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (HIGH == PORTBbits.RB4))
    {
        RB4_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (LOW == PORTBbits.RB4))
    {
        RB4_ISR(0);
    }
    else
    { /* Nothing */
    }
    
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (HIGH == PORTBbits.RB5))
    {
        RB5_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (LOW == PORTBbits.RB5))
    {
        RB5_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (HIGH == PORTBbits.RB6))
    {
        RB6_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (LOW == PORTBbits.RB6))
    {
        RB6_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (HIGH == PORTBbits.RB7))
    {
        RB7_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) && (LOW == PORTBbits.RB7))
    {
        RB7_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == PIE1bits.ADIE) && (INTERRUPT_OCCUR == PIR1bits.ADIF))
    {
        ADC_ISR();
    }
}

#else

void __interrupt() InterruptManager(void)
{
    if ((INTERRUPT_ENABLE == INTCONbits.INT0IE) && (INTERRUPT_OCCUR == INTCONbits.INT0IF))
    {
        INT0_ISR();
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCON3bits.INT1IE) && (INTERRUPT_OCCUR == INTCON3bits.INT1IF))
    {
        INT1_ISR();
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCON3bits.INT2IE) && (INTERRUPT_OCCUR == INTCON3bits.INT2IF))
    {
        INT2_ISR();
    }
    else
    { /* Nothing */
    }

    /******************************     ON CHANGE PORT B    **************************************/
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB4) && (RB4_Flag == 1))
    {
        RB4_Flag = 0;
        RB4_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB4) && (RB4_Flag == 0))
    {
        RB4_Flag = 1;
        RB4_ISR(0);
    }
    else
    { /* Nothing */
    }
    
    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB5) && (RB5_Flag == 1))
    {
        RB5_Flag = 0;
        RB5_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB5) && (RB5_Flag == 0))
    {
        RB5_Flag = 1;
        RB5_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB6) && (RB6_Flag == 1))
    {
        RB6_Flag = 0;
        RB6_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB6) && (RB6_Flag == 0))
    {
        RB6_Flag = 0;
        RB6_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (HIGH == PORTBbits.RB7) && (RB7_Flag == 1))
    {
        RB7_Flag = 0;
        RB7_ISR(1);
    }
    else if ((INTERRUPT_ENABLE == INTCONbits.RBIE) && (INTERRUPT_OCCUR == INTCONbits.RBIF) 
    && (LOW == PORTBbits.RB7) && (RB7_Flag == 0))
    {
        RB7_Flag = 1;
        RB7_ISR(0);
    }
    else
    { /* Nothing */
    }

    if ((INTERRUPT_ENABLE == PIE1bits.ADIE) && (INTERRUPT_OCCUR == PIR1bits.ADIF))
    {
        ADC_ISR();
    }
}

#endif