/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

// void handler(void);

// uint8 i = 0;

// led_t led = {
//     .port = PORTC_INDEX,
//     .pin = PIN0,
//     .status = LED_OFF,
// };

// Timer0_t timer = {
//     .interrupt_handler = handler,
//     .counter_edge = TIMER0_FALLING_EDGE,
//     .preload_value = 0xFFFA,
//     .prescalar_status = TIMER0_PRESCALAR_FEATURE_DISABLE,
//     .register_size = TIMER0_REGISTER_16BIT_SIZE,
//     .timer0_mode = TIMER0_COUNTER_CFG,
//     .TMR0_interrupt_priority = INTERRUPT_HIGH_PRIORITY,
// };



Std_ReturnType ret = E_NOT_OK;


// int main()
// {

//     Timer0_init(&timer);
//     led_initialize(&led);
//     while (1)
//     {
//     }

//     return (EXIT_SUCCESS);
// }

// void handler(void)
// {
//     i++;
//     led_turn_toggle(&led);
// }

// void app_init(void)
// {
//     ecu_layer_init();
// }

#include "application.h"
void handler(void);

int i = 0;

Timer2_t timer2 = {
    .timer2_postscaler_value = TIMER2_PRESCALER_DIV_BY_16,
    .timer2_prescaler_value = TIMER2_POSTSCALER_DIV_BY_5,
    .TMR2_InterruptHandler = handler,
    .priority = INTERRUPT_LOW_PRIORITY,
    .timer2_preload_value = 0xC0,
};

led_t led = {
    .port = PORTC_INDEX,
    .pin = PIN0,
    .status = LED_OFF,
};

ccp_t ccp1_obj;
uint8 CCP1_PWM1_Duty = 25;

int main()
{
    ccp1_obj.ccp_inst = CCP1_INST;
    ccp1_obj.CCP1_InterruptHandler = NULL;
    ccp1_obj.ccp_mode = CCP_PWM_MODE_SELECTED;
    ccp1_obj.PWM_Frequency = 20000;
    ccp1_obj.ccp_pin.port = PORTC_INDEX;
    ccp1_obj.ccp_pin.pin = PIN2;
    ccp1_obj.ccp_pin.direction = OUTPUT;
    ccp1_obj.timer2_prescaler_value = CCP_TIMER2_PRESCALER_DIV_BY_1;
    ccp1_obj.timer2_postscaler_value = CCP_TIMER2_POSTSCALER_DIV_BY_1;
    ret = CCP_Init(&ccp1_obj);

    ret = CCP_PWM_Set_Duty(&ccp1_obj, CCP1_PWM1_Duty);
        
    ret = CCP_PWM_Start(&ccp1_obj);


    led_initialize(&led);
    Timer2_init(&timer2);
    
    while(1)
    {

    }
    return (EXIT_SUCCESS);
}

void handler(void)
{
    i++;
    if(i == 10){
        led_turn_toggle(&led);
        i = 0;
    }
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt

Ahmed Mohammed Bakr     27July2023      Task-12 build mcal EEPROM interrupt

Ahmed Mohammed Bakr     30July2023      Task-13 build mcal ADC

Ahmed Mohammed Bakr     2Aug2023        Task-14 build Timer0 driver

Ahmed Mohammed Bakr     2Aug2023        Task-15 build Timer1 driver

Ahmed Mohammed Bakr     2Aug2023        Task-16 build Timer2 driver

Ahmed Mohammed Bakr     2Aug2023        Task-17 build Timer3 driver

Ahmed Mohammed Bakr     2Aug2023        Task-14 build CCP1 driver


******************************************************************* */
