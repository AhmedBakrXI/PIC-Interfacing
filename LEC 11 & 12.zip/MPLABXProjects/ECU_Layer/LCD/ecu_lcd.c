#include "ecu_lcd.h"


static Std_ReturnType lcd_send_4bits(const LCD_4bit_t *lcd, uint8 data);
static Std_ReturnType lcd_send_4bits_enable(const LCD_4bit_t *lcd);
static Std_ReturnType lcd_send_8bits_enable(const LCD_8bit_t *lcd);
static Std_ReturnType lcd_4bit_set_cursor(const LCD_4bit_t *lcd, uint8 row, uint8 column);
static Std_ReturnType lcd_8bit_set_cursor(const LCD_8bit_t *lcd, uint8 row, uint8 column);



Std_ReturnType lcd_4bit_init(const LCD_4bit_t *lcd)
{
    Std_ReturnType ret = E_OK;
    uint8 l_pin_counter = ZERO_INIT;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_direction_init(&lcd->lcd_en);
        ret = gpio_pin_direction_init(&lcd->lcd_rs);
        ret = gpio_pin_write_logic(&lcd->lcd_en, lcd->lcd_en.logic);
        ret = gpio_pin_write_logic(&lcd->lcd_rs, lcd->lcd_rs.logic);

        for (l_pin_counter = ZERO_INIT; l_pin_counter < 4; l_pin_counter++)
        {
            ret = gpio_pin_direction_init(&lcd->lcd_data[l_pin_counter]);
            ret = gpio_pin_write_logic(&lcd->lcd_data[l_pin_counter], 
                                        lcd->lcd_data[l_pin_counter].logic);
        }

        __delay_ms(20);
        ret = lcd_4bit_send_command(lcd, LCD_EIGHT_BIT_MODE);
        __delay_ms(5);
        ret = lcd_4bit_send_command(lcd, LCD_EIGHT_BIT_MODE);
        __delay_us(150);
        ret = lcd_4bit_send_command(lcd, LCD_EIGHT_BIT_MODE);

        ret = lcd_4bit_send_command(lcd, LCD_CLEAR);
        ret = lcd_4bit_send_command(lcd, LCD_HOME);
        ret = lcd_4bit_send_command(lcd, LCD_ENTRY_MODE_INC_SHIFT_OFF);
        ret = lcd_4bit_send_command(lcd, LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_OFF);
        ret = lcd_4bit_send_command(lcd, LCD_FOUR_BIT_MODE);
        ret = lcd_4bit_send_command(lcd, 0x80);
    }

    return ret;
}

Std_ReturnType lcd_4bit_send_command(const LCD_4bit_t *lcd, uint8 command)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), LOW);
        ret = lcd_send_4bits(lcd, command >> 4);
        ret = lcd_send_4bits_enable(lcd);
        ret = lcd_send_4bits(lcd, command);
        ret = lcd_send_4bits_enable(lcd);
    }

    return ret;
}

Std_ReturnType lcd_4bit_send_char(const LCD_4bit_t *lcd, uint8 data)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), HIGH);
        ret = lcd_send_4bits(lcd, data >> 4);
        ret = lcd_send_4bits_enable(lcd);
        ret = lcd_send_4bits(lcd, data);
        ret = lcd_send_4bits_enable(lcd);
    }

    return ret;
}

Std_ReturnType lcd_4bit_send_char_pos(const LCD_4bit_t *lcd, uint8 data,
                                        uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = lcd_4bit_set_cursor(lcd, row, column);
        ret = lcd_4bit_send_char(lcd, data);
    }

    return ret;
}

Std_ReturnType lcd_4bit_send_string(const LCD_4bit_t *lcd, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == lcd) || (NULL == str))
    {
        ret = E_NOT_OK;
    }
    else
    {
        while (*str)
        {
            ret = lcd_4bit_send_char(lcd, *str++);
        } 
    }

    return ret;
}

Std_ReturnType lcd_4bit_send_string_pos(const LCD_4bit_t *lcd, uint8 *str,
                                        uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == lcd) || (NULL == str))
    {
        ret = E_NOT_OK;
    }
    else
    {
        column--;
        ret = lcd_4bit_set_cursor(lcd, row, column);
        while (*str)
        {
            ret = lcd_4bit_send_char(lcd, *str++);
        }   
    }

    return ret;
}
Std_ReturnType lcd_4bit_send_custom_char(const LCD_4bit_t *lcd, const uint8 data[],
                                            uint8 row, uint8 column, uint8 mem_pos)
{
    Std_ReturnType ret = E_OK;
    uint8 lcd_counter = ZERO_INIT;

    if ((NULL == lcd) || (NULL == data))
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = lcd_4bit_send_command(lcd, (LCD_CGRAM_START + (mem_pos * 8)));

        for (lcd_counter = ZERO_INIT; lcd_counter <= 7; lcd_counter++)
        {
            ret = lcd_4bit_send_char(lcd, data[lcd_counter]);
        }
        ret = lcd_4bit_send_char_pos(lcd, mem_pos, row, column);
    }
    return ret;
}



Std_ReturnType lcd_8bit_init(const LCD_8bit_t *lcd)
{
    Std_ReturnType ret = E_OK;
    uint8 l_pin_counter = ZERO_INIT;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_direction_init(&lcd->lcd_en);
        ret = gpio_pin_direction_init(&lcd->lcd_rs);
        ret = gpio_pin_write_logic(&lcd->lcd_en, lcd->lcd_en.logic);
        ret = gpio_pin_write_logic(&lcd->lcd_rs, lcd->lcd_rs.logic);

        for (l_pin_counter = ZERO_INIT; l_pin_counter < 8; l_pin_counter++)
        {
            ret = gpio_pin_direction_init(&lcd->lcd_data[l_pin_counter]);
            ret = gpio_pin_write_logic(&lcd->lcd_data[l_pin_counter], 
                                        lcd->lcd_data[l_pin_counter].logic);
        }
        __delay_ms(20);
        ret = lcd_8bit_send_command(lcd, LCD_EIGHT_BIT_MODE);
        __delay_ms(5);
        ret = lcd_8bit_send_command(lcd, LCD_EIGHT_BIT_MODE);
        __delay_us(150);
        ret = lcd_8bit_send_command(lcd, LCD_EIGHT_BIT_MODE);

        ret = lcd_8bit_send_command(lcd, LCD_CLEAR);
        ret = lcd_8bit_send_command(lcd, LCD_HOME);
        ret = lcd_8bit_send_command(lcd, LCD_ENTRY_MODE_INC_SHIFT_OFF);
        ret = lcd_8bit_send_command(lcd, LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_OFF);
        ret = lcd_8bit_send_command(lcd, LCD_EIGHT_BIT_MODE);
        ret = lcd_8bit_send_command(lcd, 0x80);
    
    }

    return ret;
}

Std_ReturnType lcd_8bit_send_command(const LCD_8bit_t *lcd, uint8 command)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), LOW);
        
        ret = gpio_pin_write_logic(&(lcd->lcd_data[0]), (command >> 0) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[1]), (command >> 1) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[2]), (command >> 2) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[3]), (command >> 3) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[4]), (command >> 4) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[5]), (command >> 5) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[6]), (command >> 6) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[7]), (command >> 7) & 0x01);

        ret = lcd_send_8bits_enable(lcd);
    }

    return ret;
}

Std_ReturnType lcd_8bit_send_char(const LCD_8bit_t *lcd, uint8 data)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), HIGH);
        
        ret = gpio_pin_write_logic(&(lcd->lcd_data[0]), (data >> 0) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[1]), (data >> 1) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[2]), (data >> 2) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[3]), (data >> 3) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[4]), (data >> 4) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[5]), (data >> 5) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[6]), (data >> 6) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[7]), (data >> 7) & 0x01);

        ret = lcd_send_8bits_enable(lcd);
    }

    return ret;
}

Std_ReturnType lcd_8bit_send_char_pos(const LCD_8bit_t *lcd, uint8 data,
                                        uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = lcd_8bit_set_cursor(lcd, row, column);
        ret = lcd_8bit_send_char(lcd, data);
    }

    return ret;
}
Std_ReturnType lcd_8bit_send_string(const LCD_8bit_t *lcd, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == lcd) || (NULL == str))
    {
        ret = E_NOT_OK;
    }
    else
    {
        while (*str)
        {
            ret = lcd_8bit_send_char(lcd, *str++);
        }   
    }

    return ret;
}

Std_ReturnType lcd_8bit_send_string_pos(const LCD_8bit_t *lcd, uint8 *str,
                                        uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if ((NULL == lcd) || (NULL == str))
    {
        ret = E_NOT_OK;
    }
    else
    {
        column--;
        ret = lcd_8bit_set_cursor(lcd, row, column);
        while (*str)
        {
            ret = lcd_8bit_send_char(lcd, *str++);
        }   
    }

    return ret;
}
Std_ReturnType lcd_8bit_send_custom_char(const LCD_8bit_t *lcd, const uint8 data[],
                                            uint8 row, uint8 column, uint8 mem_pos)
{
    Std_ReturnType ret = E_OK;
    uint8 lcd_counter = ZERO_INIT;

    if ((NULL == lcd) || (NULL == data))
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = lcd_8bit_send_command(lcd, (LCD_CGRAM_START + (mem_pos * 8)));

        for (lcd_counter = ZERO_INIT; lcd_counter <= 7; lcd_counter++)
        {
            ret = lcd_8bit_send_char(lcd, data[lcd_counter]);
        }
        ret = lcd_8bit_send_char_pos(lcd, mem_pos, row, column);
    }
    return ret;
}


Std_ReturnType convert_byte_to_str(uint8 value, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if(NULL == str)
    {
        ret = E_NOT_OK;
    }
    else
    {
        memset(str, '/0', 4);
        sprintf(str, "%i", value);
    }

    return ret;
}

Std_ReturnType convert_short_to_str(uint16 value, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if(NULL == str)
    {
        ret = E_NOT_OK;
    }
    else
    {
        memset(str, '/0', 6);
        sprintf(str, "%i", value);
    }

    return ret;
}

Std_ReturnType convert_int_to_str(uint32 value, uint8 *str)
{
    Std_ReturnType ret = E_OK;

    if(NULL == str)
    {
        ret = E_NOT_OK;
    }
    else
    {
        memset(str, '/0', 11);
        sprintf(str, "%i", value);
    }

    return ret;
}


static Std_ReturnType lcd_send_4bits(const LCD_4bit_t *lcd, uint8 data)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_data[0]), (data >> 0) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[1]), (data >> 1) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[2]), (data >> 2) & 0x01);
        ret = gpio_pin_write_logic(&(lcd->lcd_data[3]), (data >> 3) & 0x01);
    }

    return ret;
}

static Std_ReturnType lcd_send_4bits_enable(const LCD_4bit_t *lcd)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_en), HIGH);
        __delay_us(5);
        ret = gpio_pin_write_logic(&(lcd->lcd_en), LOW);
    }

    return ret;
}

static Std_ReturnType lcd_send_8bits_enable(const LCD_8bit_t *lcd)
{
    Std_ReturnType ret = E_OK;

    if (NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_en), HIGH);
        __delay_us(5);
        ret = gpio_pin_write_logic(&(lcd->lcd_en), LOW);
    }

    return ret;
}

static Std_ReturnType lcd_4bit_set_cursor(const LCD_4bit_t *lcd, uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if(NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        column--;
        switch (row)
        {
        case ROW1:
            ret = lcd_4bit_send_command(lcd, (0x80 + column));
            break;

        case ROW2:
            ret = lcd_4bit_send_command(lcd, (0xC0 + column));
            break;

        case ROW3:
            ret = lcd_4bit_send_command(lcd, (0x94 + column));
            break;

        case ROW4:
            ret = lcd_4bit_send_command(lcd, (0xd4 + column));
            break;

        default:
            break;
        }
    }

    return ret;
}

static Std_ReturnType lcd_8bit_set_cursor(const LCD_8bit_t *lcd, uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;

    if(NULL == lcd)
    {
        ret = E_NOT_OK;
    }
    else
    {
        column--;
        switch (row)
        {
        case ROW1:
            ret = lcd_8bit_send_command(lcd, (0x80 + column));
            break;

        case ROW2:
            ret = lcd_8bit_send_command(lcd, (0xC0 + column));
            break;

        case ROW3:
            ret = lcd_8bit_send_command(lcd, (0x94 + column));
            break;

        case ROW4:
            ret = lcd_8bit_send_command(lcd, (0xd4 + column));
            break;

        default:
            break;
        }
    }

    return ret;
}


