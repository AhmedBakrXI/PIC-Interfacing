#include "hal_timer3.h"

#if TIMER3_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*TMR3_interrupt_handler)(void) = NULL;
#endif
static uint16 timer3_preload = ZERO_INIT;

static inline void Timer3_Mode_Select(const Timer3_t *_timer);

/**
 * @brief initializes timer3 module
 *
 * @param _timer pointer to timer3 module configurations @ref Timer3_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer3_init(const Timer3_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TIMER3_MODULE_DISABLE();

        TIMER3_PRESCALER_SELECT(_timer->timer3_prescaler_value);
        Timer3_Mode_Select(_timer);
        TMR3H = (_timer->timer3_preload_value) >> 8;
        TMR3L = (uint8)(_timer->timer3_preload_value);
        timer3_preload = _timer->timer3_preload_value;

#if TIMER2_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GLOBAL_ENABLE();
        INTERRUPT_PERIPHERAL_ENABLE();
        TIMER3_INTERRUPT_ENABLE();
        TIMER3_INTERRUPT_FLAG_CLEAR();
        TMR3_interrupt_handler = _timer->TMR3_InterruptHandler;
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_FEATURE_ENABLE();
        if (INTERRUPT_HIGH_PRIORITY == _timer->priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            TIMER3_INTERRUPT_PRIORITY_HIGH();
        }
        else if (INTERRUPT_LOW_PRIORITY == _timer->priority)
        {
            INTERRUPT_GLOBAL_LOW_ENABLE();
            TIMER3_INTERRUPT_PRIORITY_LOW();
        }
        else
        {
            /* NOTHING */
        }
#endif
#endif
        TIMER3_MODULE_ENABLE();
    }

    return ret;
}


/**
 * @brief deinitializes timer3 module
 *
 * @param _timer pointer to timer3 module configurations @ref Timer3_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer3_deinit(const Timer3_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TIMER3_MODULE_DISABLE();
#if TIMER3_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
        TIMER3_INTERRUPT_DISABLE();
#endif
    }

    return ret;
}

/**
 * @brief
 *
 * @param _timer  pointer to timer3 module configurations @ref Timer3_t
 * @param _value  value to be written to Timer3 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer3_write(const Timer3_t *_timer, uint16 _value)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TMR3H = (_value) >> 8;
        TMR3L = (uint8)(_value);
    }

    return ret;
}

/**
 * @brief
 *
 * @param _timer  pointer to timer3 module configurations @ref Timer3_t
 * @param _value  pointer to value to be read from Timer3 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer3_read(const Timer3_t *_timer, uint16 *_value)
{
    Std_ReturnType ret = E_OK;
    uint8 l_tmr3l = ZERO_INIT, l_tmr3h = ZERO_INIT;

    if ((NULL == _timer) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        l_tmr3l = TMR3L;
        l_tmr3h = TMR3H;
        *_value = (uint16)((l_tmr3h << 8) + l_tmr3l);
    }

    return ret;
}

static inline void Timer3_Mode_Select(const Timer3_t *_timer)
{
    if(TIMER3_TIMER_MODE == _timer->timer3_mode){
        TIMER3_TIMER_MODE_ENABLE();
    }
    else if(TIMER3_COUNTER_MODE == _timer->timer3_mode){
        TIMER3_COUNTER_MODE_ENABLE();
        if(TIMER3_ASYNC_COUNTER_MODE == _timer->timer3_counter_mode){
            TIMER3_ASYNC_COUNTER_MODE_ENABLE();
        }
        else if(TIMER3_SYNC_COUNTER_MODE == _timer->timer3_counter_mode){
            TIMER3_SYNC_COUNTER_MODE_ENABLE();
        }
        else{ /* Nothing */ }
    }
    else{ /* Nothing */ }
}
