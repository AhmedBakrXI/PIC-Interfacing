/* 
 * File:   mcal_internal_interrupt.h
 * Author: AHMED BAKR
 *
 * Created on July 26, 2023, 1:46 AM
 */

#ifndef MCAL_INTERNAL_INTERRUPT_H
#define	MCAL_INTERNAL_INTERRUPT_H



/*  Section :   includes    */
#include "mcal_interrupt_cfg.h"
/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */
#if INTERRUPT_FEATURE_ENABLE == ADC_INTERRUPT_FEATURE_ENABLE

    #define ADC_INTERRUPT_ENABLE()          (PIE1bits.ADIE = 1)

    #define ADC_INTERRUPT_DISABLE()         (PIE1bits.ADIE = 0)

    #define ADC_INTERRUPT_CLEAR_FLAG()      (PIR1bits.ADIF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define ADC_INTERRUPT_PRIORITY_HIGH()   (IPR1bits.ADIP = INTERRUPT_HIGH_PRIORITY)

    #define ADC_INTERRUPT_PRIORITY_LOW()    (IPR1bits.ADIP = INTERRUPT_LOW_PRIORITY)

#endif

#endif

#if TIMER0_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define TIMER0_INTERRUPT_ENABLE()           (INTCONbits.TMR0IE = 1)
    #define TIMER0_INTERRUPT_DISABLE()          (INTCONbits.TMR0IE = 0)
    #define TIMER0_INTERRUPT_FLAG_CLEAR()       (INTCONbits.TMR0IF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    #define TIMER0_INTERRUPT_PRIORITY_HIGH()    (INTCON2bits.TMR0IP = INTERRUPT_HIGH_PRIORITY)
    #define TIMER0_INTERRUPT_PRIORITY_LOW()     (INTCON2bits.TMR0IP = INTERRUPT_LOW_PRIORITY)
#endif
#endif

#if TIMER1_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define TIMER1_INTERRUPT_ENABLE()           (PIE1bits.TMR1IE = 1)
    #define TIMER1_INTERRUPT_DISABLE()          (PIE1bits.TMR1IE = 0)
    #define TIMER1_INTERRUPT_FLAG_CLEAR()       (PIR1bits.TMR1IF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    #define TIMER1_INTERRUPT_PRIORITY_HIGH()    (IPR1bits.TMR1IP = INTERRUPT_HIGH_PRIORITY)
    #define TIMER1_INTERRUPT_PRIORITY_LOW()     (IPR1bits.TMR1IP = INTERRUPT_LOW_PRIORITY)
#endif
#endif

#if TIMER2_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define TIMER2_INTERRUPT_ENABLE()           (PIE1bits.TMR2IE = 1)
    #define TIMER2_INTERRUPT_DISABLE()          (PIE1bits.TMR2IE = 0)
    #define TIMER2_INTERRUPT_FLAG_CLEAR()       (PIR1bits.TMR2IF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    #define TIMER2_INTERRUPT_PRIORITY_HIGH()    (IPR1bits.TMR2IP = INTERRUPT_HIGH_PRIORITY)
    #define TIMER2_INTERRUPT_PRIORITY_LOW()     (IPR1bits.TMR2IP = INTERRUPT_LOW_PRIORITY)
#endif
#endif

#if TIMER3_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

    #define TIMER3_INTERRUPT_ENABLE()           (PIE2bits.TMR3IE = 1)
    #define TIMER3_INTERRUPT_DISABLE()          (PIE2bits.TMR3IE = 0)
    #define TIMER3_INTERRUPT_FLAG_CLEAR()       (PIR2bits.TMR3IF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
    #define TIMER3_INTERRUPT_PRIORITY_HIGH()    (IPR2bits.TMR3IP = INTERRUPT_HIGH_PRIORITY)
    #define TIMER3_INTERRUPT_PRIORITY_LOW()     (IPR2bits.TMR3IP = INTERRUPT_LOW_PRIORITY)
#endif
#endif

#if CCP1_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
/* This routine clears the interrupt enable for the CCP1 Module */
#define CCP1_InterruptDisable()         (PIE1bits.CCP1IE = 0)
/* This routine sets the interrupt enable for the CCP1 Module */
#define CCP1_InterruptEnable()          (PIE1bits.CCP1IE = 1)
/* This routine clears the interrupt flag for the CCP1 Module */
#define CCP1_InterruptFlagClear()       (PIR1bits.CCP1IF = 0)
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE 
/* This routine set the CCP1 Module Interrupt Priority to be High priority */
#define CCP1_HighPrioritySet()          (IPR1bits.CCP1IP = 1)
/* This routine set the CCP1 Module Interrupt Priority to be Low priority */
#define CCP1_LowPrioritySet()           (IPR1bits.CCP1IP = 0)
#endif
#endif
/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif	/* MCAL_INTERNAL_INTERRUPT_H */

