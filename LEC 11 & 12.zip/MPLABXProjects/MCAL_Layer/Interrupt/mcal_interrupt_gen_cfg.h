/* 
 * File:   mcal_interrupt_gen_cfg.h
 * Author: AHMED BAKR
 *
 * Created on July 26, 2023, 2:36 AM
 */

#ifndef MCAL_INTERRUPT_GEN_CFG_H
#define	MCAL_INTERRUPT_GEN_CFG_H

/*  Section :   includes    */


/*  Section :   Macro Declarations    */

#define INTERRUPT_FEATURE_ENABLE            1U

// #define INTERRUPT_PRIORITY_LEVELS_ENABLE    INTERRUPT_FEATURE_ENABLE

#define INTERRUPT_INTX_FEATURE_ENABLE       INTERRUPT_FEATURE_ENABLE

#define INTERRUPT_OnChange_FEATURE_ENABLE   INTERRUPT_FEATURE_ENABLE

#define ADC_INTERRUPT_FEATURE_ENABLE        INTERRUPT_FEATURE_ENABLE

#define TIMER0_INTERRUPT_FEATURE_ENABLE     INTERRUPT_FEATURE_ENABLE

#define TIMER1_INTERRUPT_FEATURE_ENABLE     INTERRUPT_FEATURE_ENABLE

#define TIMER2_INTERRUPT_FEATURE_ENABLE     INTERRUPT_FEATURE_ENABLE

#define TIMER3_INTERRUPT_FEATURE_ENABLE     INTERRUPT_FEATURE_ENABLE

#define CCP1_INTERRUPT_FEATURE_ENABLE       INTERRUPT_FEATURE_ENABLE

/*  Section :   Macro Functions Declarations    */


/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif	/* MCAL_INTERRUPT_GEN_CFG_H */

