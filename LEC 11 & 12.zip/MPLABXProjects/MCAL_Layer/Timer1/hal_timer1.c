#include "hal_timer1.h"

#if TIMER1_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
static volatile void (*TMR1_interrupt_handler)(void) = NULL;
#endif
static volatile uint16 timer1_preload = ZERO_INIT;

static inline void Timer1_Mode_Select(const Timer1_t *_timer);

/**
 * @brief initializes timer1 module
 *
 * @param _timer  pointer to timer1 module configurations @ref Timer1_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer1_init(const Timer1_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TIMER1_MODULE_DISABLE();

        TIMER1_PRESCALER_SELECT(_timer->prescalar_value);
        Timer1_Mode_Select(_timer);
        TMR1H = (_timer->preload_value >> 8);
        TMR1L = (uint8) (_timer->preload_value);
        timer1_preload = _timer->preload_value;

#if TIMER1_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GLOBAL_ENABLE();
        INTERRUPT_PERIPHERAL_ENABLE();
        TIMER1_INTERRUPT_ENABLE();
        TIMER1_INTERRUPT_FLAG_CLEAR();
        TMR1_interrupt_handler = _timer->interrupt_handler;
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_FEATURE_ENABLE();
        if (INTERRUPT_HIGH_PRIORITY == _timer->TMR1_interrupt_priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            TIMER1_INTERRUPT_PRIORITY_HIGH();
        }
        else if (INTERRUPT_LOW_PRIORITY == _timer->TMR1_interrupt_priority)
        {
            INTERRUPT_GLOBAL_LOW_ENABLE();
            TIMER1_INTERRUPT_PRIORITY_LOW();
        }
        else
        {
            /* NOTHING */
        }
#endif
#endif

        TIMER1_MODULE_ENABLE();
    }
    return ret;
}

/**
 * @brief deinitializes timer1 module
 *
 * @param _timer  pointer to timer1 module configurations @ref Timer1_t
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer1_deinit(const Timer1_t *_timer)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {        // Disable timer0 module
        TIMER1_MODULE_DISABLE();
#if TIMER1_INTERRUPT_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER1_INTERRUPT_DISABLE();
#endif
    }
    return ret;
}

/**
 * @brief
 *
 * @param _timer  pointer to timer0 module configurations @ref Timer1_t
 * @param _value  value to be written to Timer0 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer1_write(const Timer1_t *_timer, uint16 _value)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _timer)
    {
        ret = E_NOT_OK;
    }
    else
    {
        TMR1H = (_value) >> 8;
        TMR1L = (uint8)(_value);
    }
    return ret;
}

/**
 * @brief
 *
 * @param _timer pointer to timer1 module configurations @ref Timer1_t
 * @param _value  pointer to value to be read from Timer1 register
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType Timer1_read(const Timer1_t *_timer, uint16 *_value)
{
    Std_ReturnType ret = E_OK;
    uint8 l_tmr1h = ZERO_INIT, l_tmr1l = ZERO_INIT;

    if ((NULL == _timer) || (NULL == _value))
    {
        ret = E_NOT_OK;
    }
    else
    {
        l_tmr1l = TMR1L;
        l_tmr1h = TMR1H;

        *_value = (uint16)(l_tmr1h << 8) + (l_tmr1l);
    }
    return ret;
}

void TMR1_ISR(void){
    TIMER1_INTERRUPT_FLAG_CLEAR();     /* Clear the interrupt flag */
    TMR1H = (timer1_preload) >> 8;   /* Initialize the pre-loaded value again */
    TMR1L = (uint8)(timer1_preload); /* Initialize the pre-loaded value again */
    if(TMR1_interrupt_handler){
        TMR1_interrupt_handler();     /* Call the callback function */
    }
}


static inline void Timer1_Mode_Select(const Timer1_t *_timer)
{
    if(TIMER1_TIMER_MODE == _timer->timer1_mode)
    {
        TIMER1_TIMER_MODE_ENABLE();
    }
    else if(TIMER1_COUNTER_MODE == _timer->timer1_mode)
    {
        TIMER1_COUNTER_MODE_ENABLE();
        if(TIMER1_ASYNC_COUNTER_MODE == _timer->counter_mode)
        {
            TIMER1_ASYNC_COUNTER_MODE_ENABLE();
        }
        else if(TIMER1_SYNC_COUNTER_MODE == _timer->counter_mode)
        {
            TIMER1_SYNC_COUNTER_MODE_ENABLE();
        }
        else {/* Nothing */}
    }
    else {/* Nothing */}
}

