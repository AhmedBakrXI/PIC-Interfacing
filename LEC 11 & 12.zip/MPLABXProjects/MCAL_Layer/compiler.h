/*
 * File:   compiler.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:14 PM
 */

#ifndef COMPILER_H
#define COMPILER_H
#include <xc.h>
/*  Section :   includes    */

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif /* COMPILER_H */
