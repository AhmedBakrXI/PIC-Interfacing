#include "mcal_external_interrupt.h"

static void (*INT0_Handler)(void) = NULL;
static void (*INT1_Handler)(void) = NULL;
static void (*INT2_Handler)(void) = NULL;

static void (*RB4_Handler_high)(void) = NULL;
static void (*RB4_Handler_low)(void) = NULL;

static void (*RB5_Handler_high)(void) = NULL;
static void (*RB5_Handler_low)(void) = NULL;

static void (*RB6_Handler_high)(void) = NULL;
static void (*RB6_Handler_low)(void) = NULL;

static void (*RB7_Handler_high)(void) = NULL;
static void (*RB7_Handler_low)(void) = NULL;

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType INT0_Set_Interrupt_Handler(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType INT1_Set_Interrupt_Handler(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType INT2_Set_Interrupt_Handler(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType INTx_Set_Interrupt_Handler(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB4_Set_Interrupt_Handler_low(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB4_Set_Interrupt_Handler_high(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB5_Set_Interrupt_Handler_low(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB5_Set_Interrupt_Handler_high(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB6_Set_Interrupt_Handler_low(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB6_Set_Interrupt_Handler_high(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB7_Set_Interrupt_Handler_low(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param Handler 
 * @return Std_ReturnType 
 */
static Std_ReturnType RB7_Set_Interrupt_Handler_high(void (*Handler)(void));

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
static Std_ReturnType RBx_Set_Interrupt_Handler(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Enable(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Disable(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Priority_Init(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Edge_Init(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Pin_Init(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_INTx_Clear_Flag(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_RBx_Enable(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_RBx_Disable(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_RBx_Priority_Init(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
static Std_ReturnType Interrupt_RBx_Pin_Init(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_INTx_init(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        /*  Disable External Interrupt  */
        ret = Interrupt_INTx_Disable(_intx);
        /*  Clear External Interrupt Flag   */
        ret = Interrupt_INTx_Clear_Flag(_intx);
        /*  Configure External Interrupt Edge   */
        ret = Interrupt_INTx_Edge_Init(_intx);
/*  Configure External Interrupt Priority   */
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        ret = Interrupt_INTx_Priority_Init(_intx);
#endif
        /*  Configure External Interrupt I/O Pin    */
        ret = Interrupt_INTx_Pin_Init(_intx);
        /*  Configure External Interrupt Callback "Handler" */
        ret = INTx_Set_Interrupt_Handler(_intx);
        /*  Enable External Interrupt*/
        ret = Interrupt_INTx_Enable(_intx);
    }

    return ret;
}

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_INTx_cancel(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = Interrupt_INTx_Disable(_intx);
    }

    return ret;
}

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_RBx_init(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        /*  Disable External Interrupt  */
        ret = Interrupt_RBx_Disable(_RBx);
        /*  Clear External Interrupt Flag   */
        ret = INTERRUPT_RBX_CLEAR_FLAG();

/*  Configure External Interrupt Priority   */
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
        ret = Interrupt_RBx_Priority_Init(_RBx);
#endif
        /*  Configure External Interrupt I/O Pin    */
        ret = Interrupt_RBx_Pin_Init(_RBx);
        /*  Configure External Interrupt Callback "Handler" */
        ret = RBx_Set_Interrupt_Handler(_RBx);
        /*  Enable External Interrupt*/
        ret = Interrupt_RBx_Enable(_RBx);
    }

    return ret;
}

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_RBx_cancel(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = Interrupt_RBx_Disable(_RBx);
    }

    return ret;
}

/*------------------------  Static Functions  ---------------------------*/

static Std_ReturnType INT0_Set_Interrupt_Handler(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        INT0_Handler = Handler;
    }

    return ret;
}

static Std_ReturnType INT1_Set_Interrupt_Handler(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        INT1_Handler = Handler;
    }

    return ret;
}

static Std_ReturnType INT2_Set_Interrupt_Handler(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        INT2_Handler = Handler;
    }

    return ret;
}

static Std_ReturnType INTx_Set_Interrupt_Handler(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {
        case INT0_INTERRUPT:
            ret = INT0_Set_Interrupt_Handler(_intx->interrupt_handler);
            break;

        case INT1_INTERRUPT:
            ret = INT1_Set_Interrupt_Handler(_intx->interrupt_handler);
            break;

        case INT2_INTERRUPT:
            ret = INT2_Set_Interrupt_Handler(_intx->interrupt_handler);
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

static Std_ReturnType RB4_Set_Interrupt_Handler_low(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB4_Handler_low = Handler;
    }

    return ret;
}

static Std_ReturnType RB4_Set_Interrupt_Handler_high(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB4_Handler_high = Handler;
    }

    return ret;
}

static Std_ReturnType RB5_Set_Interrupt_Handler_low(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB5_Handler_low = Handler;
    }

    return ret;
}

static Std_ReturnType RB5_Set_Interrupt_Handler_high(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB5_Handler_high = Handler;
    }

    return ret;
}

static Std_ReturnType RB6_Set_Interrupt_Handler_low(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB6_Handler_low = Handler;
    }

    return ret;
}

static Std_ReturnType RB6_Set_Interrupt_Handler_high(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB6_Handler_high = Handler;
    }

    return ret;
}

static Std_ReturnType RB7_Set_Interrupt_Handler_low(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB7_Handler_low = Handler;
    }

    return ret;
}

static Std_ReturnType RB7_Set_Interrupt_Handler_high(void (*Handler)(void))
{
    Std_ReturnType ret = E_OK;

    if (NULL == Handler)
    {
        ret = E_NOT_OK;
    }
    else
    {
        RB7_Handler_high = Handler;
    }

    return ret;
}

static Std_ReturnType RBx_Set_Interrupt_Handler(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_NOT_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_RBx->pin.pin)
        {
        case PIN4:
            ret = RB4_Set_Interrupt_Handler_low(_RBx->interrupt_handler_low);
            ret = RB4_Set_Interrupt_Handler_high(_RBx->interrupt_handler_high);
            break;

        case PIN5:
            ret = RB5_Set_Interrupt_Handler_low(_RBx->interrupt_handler_low);
            ret = RB5_Set_Interrupt_Handler_high(_RBx->interrupt_handler_high);
            break;

        case PIN6:
            ret = RB6_Set_Interrupt_Handler_low(_RBx->interrupt_handler_low);
            ret = RB6_Set_Interrupt_Handler_high(_RBx->interrupt_handler_high);
            break;

        case PIN7:
            ret = RB7_Set_Interrupt_Handler_low(_RBx->interrupt_handler_low);
            ret = RB7_Set_Interrupt_Handler_high(_RBx->interrupt_handler_high);
            break;

        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

/**
 * @brief 
 * 
 */
void INT0_ISR(void)
{
    /*  Clear Interrupt Flag    */
    INT0_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (INT0_Handler)
    {
        INT0_Handler();
    }
}

/**
 * @brief 
 * 
 */
void INT1_ISR(void)
{
    /*  Clear Interrupt Flag    */
    INT1_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (INT1_Handler)
    {
        INT1_Handler();
    }
}

/**
 * @brief 
 * 
 */
void INT2_ISR(void)
{
    /*  Clear Interrupt Flag    */
    INT2_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (INT2_Handler)
    {
        INT2_Handler();
    }
}

/**
 * @brief 
 * 
 * @param src 
 */
void RB4_ISR(uint8 src)
{
    /*  Clear Interrupt Flag    */
    INTERRUPT_RBX_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (0 == src)
    {
        if (RB4_Handler_low)
        {
            RB4_Handler_low();
        }
        else
        { /* Nothing */
        }
    }
    else if (1 == src)
    {
        if (RB4_Handler_high)
        {
            RB4_Handler_high();
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

/**
 * @brief 
 * 
 * @param src 
 */
void RB5_ISR(uint8 src)
{
    /*  Clear Interrupt Flag    */
    INTERRUPT_RBX_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (0 == src)
    {
        if (RB5_Handler_low)
        {
            RB5_Handler_low();
        }
        else
        { /* Nothing */
        }
    }
    else if (1 == src)
    {
        if (RB5_Handler_high)
        {
            RB5_Handler_high();
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

/**
 * @brief 
 * 
 * @param src 
 */
void RB6_ISR(uint8 src)
{
    /*  Clear Interrupt Flag    */
    INTERRUPT_RBX_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (0 == src)
    {
        if (RB6_Handler_low)
        {
            RB6_Handler_low();
        }
        else
        { /* Nothing */
        }
    }
    else if (1 == src)
    {
        if (RB6_Handler_high)
        {
            RB6_Handler_high();
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

/**
 * @brief 
 * 
 * @param src 
 */
void RB7_ISR(uint8 src)
{
    /*  Clear Interrupt Flag    */
    INTERRUPT_RBX_CLEAR_FLAG();

    /*  Code   */

    /*  Callback  */
    if (0 == src)
    {
        if (RB7_Handler_low)
        {
            RB7_Handler_low();
        }
        else
        { /* Nothing */
        }
    }
    else if (1 == src)
    {
        if (RB7_Handler_high)
        {
            RB7_Handler_high();
        }
        else
        { /* Nothing */
        }
    }
    else
    { /* Nothing */
    }
}

static Std_ReturnType Interrupt_INTx_Enable(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {
        case INT0_INTERRUPT:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
            INTERRUPT_PRIORITY_FEATURE_ENABLE();
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();

#else
            INTERRUPT_GLOBAL_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
#endif
            INT0_INTERRUPT_ENABLE();
            break;

        case INT1_INTERRUPT:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

            INTERRUPT_PRIORITY_FEATURE_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();

            if (INTERRUPT_HIGH_PRIORITY == _intx->priority)
            {
                INTERRUPT_GLOBAL_HIGH_ENABLE();
            }
            else if (INTERRUPT_LOW_PRIORITY == _intx->priority)
            {
                INTERRUPT_GLOBAL_LOW_ENABLE();
            }
            else
            { /* Nothing */
            }
#else
            INTERRUPT_GLOBAL_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
#endif
            INT1_INTERRUPT_ENABLE();
            break;

        case INT2_INTERRUPT:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE
            INTERRUPT_PRIORITY_FEATURE_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();

            if (INTERRUPT_HIGH_PRIORITY == _intx->priority)
            {
                INTERRUPT_GLOBAL_HIGH_ENABLE();
            }
            else if (INTERRUPT_LOW_PRIORITY == _intx->priority)
            {
                INTERRUPT_GLOBAL_LOW_ENABLE();
            }
            else
            { /* Nothing */
            }
#else
            INTERRUPT_GLOBAL_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
#endif
            INT2_INTERRUPT_ENABLE();
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

static Std_ReturnType Interrupt_INTx_Disable(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {
        case INT0_INTERRUPT:
            INT0_INTERRUPT_DISABLE();
            break;

        case INT1_INTERRUPT:
            INT1_INTERRUPT_DISABLE();
            break;

        case INT2_INTERRUPT:
            INT2_INTERRUPT_DISABLE();
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

static Std_ReturnType Interrupt_INTx_Priority_Init(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {

        case INT1_INTERRUPT:
            if (INTERRUPT_HIGH_PRIORITY == _intx->priority)
            {
                INT1_SET_HIGH_PRIORITY();
            }
            else if (INTERRUPT_LOW_PRIORITY == _intx->priority)
            {
                INT1_SET_LOW_PRIORITY();
            }
            else
            {
                /*  Nothing  */
            }

            break;

        case INT2_INTERRUPT:
            if (INTERRUPT_HIGH_PRIORITY == _intx->priority)
            {
                INT2_SET_HIGH_PRIORITY();
            }
            else if (INTERRUPT_LOW_PRIORITY == _intx->priority)
            {
                INT2_SET_LOW_PRIORITY();
            }
            else
            {
                /*  Nothing  */
            }
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

#endif

static Std_ReturnType Interrupt_INTx_Edge_Init(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {
        case INT0_INTERRUPT:
            if (RISING_EDGE == _intx->edge)
            {
                INT0_RISING_EDGE();
            }
            else if (FALLING_EDGE == _intx->edge)
            {
                INT0_FALLING_EDGE();
            }
            else
            {
                /*  Nothing  */
            }
            break;

        case INT1_INTERRUPT:
            if (RISING_EDGE == _intx->edge)
            {
                INT1_RISING_EDGE();
            }
            else if (FALLING_EDGE == _intx->edge)
            {
                INT1_FALLING_EDGE();
            }
            else
            {
                /*  Nothing  */
            }
            break;

        case INT2_INTERRUPT:
            if (RISING_EDGE == _intx->edge)
            {
                INT2_RISING_EDGE();
            }
            else if (FALLING_EDGE == _intx->edge)
            {
                INT2_FALLING_EDGE();
            }
            else
            {
                /*  Nothing  */
            }
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

static Std_ReturnType Interrupt_INTx_Pin_Init(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_direction_init(&_intx->pin);
    }

    return ret;
}

static Std_ReturnType Interrupt_INTx_Clear_Flag(const Interrupt_INTx_t *_intx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _intx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        switch (_intx->source)
        {
        case INT0_INTERRUPT:
            INT0_CLEAR_FLAG();
            break;

        case INT1_INTERRUPT:
            INT1_CLEAR_FLAG();
            break;

        case INT2_INTERRUPT:
            INT2_CLEAR_FLAG();
            break;
        default:
            ret = E_NOT_OK;
            break;
        }
    }

    return ret;
}

static Std_ReturnType Interrupt_RBx_Enable(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        INTERRUPT_RBX_ENABLE();
    }

    return ret;
}

static Std_ReturnType Interrupt_RBx_Disable(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        INTERRUPT_RBX_DISABLE();
    }

    return ret;
}

static Std_ReturnType Interrupt_RBx_Priority_Init(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        if (INTERRUPT_HIGH_PRIORITY == _RBx->priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
            INTERRUPT_RBX_SET_HIGH_PRIORITY();
        }
        else if (INTERRUPT_LOW_PRIORITY == _RBx->priority)
        {
            INTERRUPT_GLOBAL_HIGH_ENABLE();
            INTERRUPT_PERIPHERAL_ENABLE();
            INTERRUPT_RBX_SET_LOW_PRIORITY();
        }
        else
        { /* Nothing */
        }
    }

    return ret;
}

static Std_ReturnType Interrupt_RBx_Pin_Init(const Interrupt_RBx_t *_RBx)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _RBx)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_direction_init(&_RBx->pin);
    }

    return ret;
}
