/*
 * File:   ecu_button.h
 * Author: AHMED BAKR
 *
 * Created on July 20, 2023, 6:54 PM
 */

#ifndef ECU_BUTTON_H
#define ECU_BUTTON_H

#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "ecu_button_cfg.h"

typedef enum
{
    BTN_PRESSED,
    BTN_RELEASED
} button_state_t;

typedef enum
{
    ACTIVE_LOW,
    ACTIVE_HIGH
} button_active_t;

typedef struct
{
    pin_config_t btn_pin;
    button_state_t button_state;
    button_active_t button_active;
} button_t;

/**
 * @brief initialize the button as an input pin @ref button_t
 *
 * @param btn
 * @return Std_ReturnType Status of the function
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue to perform this action
 */
Std_ReturnType btn_init(const button_t *btn);

/**
 * @brief Read the state of the button
 * @param btn pointer to the button configurations
 * @param btn_state button state @ref button_state_t
 * @return  Status of the function
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType btn_read(const button_t *btn, button_state_t *btn_state);

#endif /* ECU_BUTTON_H */
