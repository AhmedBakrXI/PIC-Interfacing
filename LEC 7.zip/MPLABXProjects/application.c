/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

void Int0_app_ISR(void);
void Int1_app_ISR(void);
void Int2_app_ISR(void);
void Int3_app_ISR(void);

led_t led_yellow = {
    .status = LED_OFF,
    .port = PORTC_INDEX,
    .pin = PIN0,
};

led_t led_blue = {
    .status = LED_OFF,
    .port = PORTC_INDEX,
    .pin = PIN1,
};

led_t led_red = {
    .status = LED_OFF,
    .port = PORTC_INDEX,
    .pin = PIN2,
};

led_t led_green = {
    .status = LED_OFF,
    .port = PORTC_INDEX,
    .pin = PIN3,
};

// Interrupt_INTx_t int0_obj = {
//     .interrupt_handler = Int0_app_ISR,
//     .edge = FALLING_EDGE,
//     .priority = INTERRUPT_HIGH_PRIORITY,
//     .source = INT0_INTERRUPT,
//     .pin.port = PORTB_INDEX,
//     .pin.pin = PIN0,
//     .pin.logic = LOW,
//     .pin.direction = INPUT,
// };

// Interrupt_INTx_t int1_obj = {
//     .interrupt_handler = Int1_app_ISR,
//     .edge = FALLING_EDGE,
//     .priority = INTERRUPT_HIGH_PRIORITY,
//     .source = INT1_INTERRUPT,
//     .pin.port = PORTB_INDEX,
//     .pin.pin = PIN1,
//     .pin.logic = LOW,
//     .pin.direction = INPUT,
// };

// Interrupt_INTx_t int2_obj = {
//     .interrupt_handler = Int2_app_ISR,
//     .edge = FALLING_EDGE,
//     .priority = INTERRUPT_LOW_PRIORITY,
//     .source = INT2_INTERRUPT,
    // .pin.port = PORTB_INDEX,
    // .pin.pin = PIN2,
    // .pin.logic = LOW,
    // .pin.direction = INPUT,
// };

Interrupt_RBx_t RB4_obj = {
    .interrupt_handler_high = Int0_app_ISR,
    .interrupt_handler_low = Int1_app_ISR,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .pin.port = PORTB_INDEX,
    .pin.pin = PIN4,
    .pin.logic = LOW,
    .pin.direction = INPUT,
};

Interrupt_RBx_t RB5_obj = {
    .interrupt_handler_high = Int1_app_ISR,
    .interrupt_handler_low = Int0_app_ISR,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .pin.port = PORTB_INDEX,
    .pin.pin = PIN5,
    .pin.logic = LOW,
    .pin.direction = INPUT,
};

Interrupt_RBx_t RB6_obj = {
    .interrupt_handler_high = Int2_app_ISR,
    .interrupt_handler_low = Int1_app_ISR,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .pin.port = PORTB_INDEX,
    .pin.pin = PIN6,
    .pin.logic = LOW,
    .pin.direction = INPUT,
};

Interrupt_RBx_t RB7_obj = {
    .interrupt_handler_high = Int3_app_ISR,
    .interrupt_handler_low = Int2_app_ISR,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .pin.port = PORTB_INDEX,
    .pin.pin = PIN7,
    .pin.logic = LOW,
    .pin.direction = INPUT,
};

Std_ReturnType ret = E_NOT_OK;

int main()
{
    led_initialize(&led_yellow);
    led_initialize(&led_blue);
    led_initialize(&led_red);
    led_initialize(&led_green);

    ret = Interrupt_RBx_init(&RB4_obj);
    ret = Interrupt_RBx_init(&RB5_obj);
    ret = Interrupt_RBx_init(&RB6_obj);
    ret = Interrupt_RBx_init(&RB7_obj);



    // ret = Interrupt_INTx_init(&int0_obj);
    // ret = Interrupt_INTx_init(&int1_obj);
    // ret = Interrupt_INTx_init(&int2_obj);

    while (1)
    {
    }

    return (EXIT_SUCCESS);
}

void app_init(void)
{
    ecu_layer_init();
}

void Int0_app_ISR(void)
{
    led_turn_on(&led_yellow);
    __delay_ms(1000);
    led_turn_off(&led_yellow);
    __delay_ms(1000);
}

void Int1_app_ISR(void)
{
    led_turn_on(&led_blue);
    __delay_ms(5000);
    led_turn_off(&led_blue);
}

void Int2_app_ISR(void)
{
    led_turn_on(&led_red);
    __delay_ms(5000);
    led_turn_off(&led_red);
}

void Int3_app_ISR(void)
{
    led_turn_on(&led_green);
    __delay_ms(5000);
    led_turn_off(&led_green);
}
// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt
******************************************************************* */
