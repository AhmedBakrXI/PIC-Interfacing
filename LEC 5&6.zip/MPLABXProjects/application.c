/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

// Keypad_t keypad = {
//     .keypad_rows_pins[0].port = PORTC_INDEX,
//     .keypad_rows_pins[0].pin = PIN0,
//     .keypad_rows_pins[0].direction = OUTPUT,
//     .keypad_rows_pins[0].logic = HIGH,

//     .keypad_rows_pins[1].port = PORTC_INDEX,
//     .keypad_rows_pins[1].pin = PIN1,
//     .keypad_rows_pins[1].direction = OUTPUT,
//     .keypad_rows_pins[1].logic = LOW,

//     .keypad_rows_pins[2].port = PORTC_INDEX,
//     .keypad_rows_pins[2].pin = PIN2,
//     .keypad_rows_pins[2].direction = OUTPUT,
//     .keypad_rows_pins[2].logic = LOW,

//     .keypad_rows_pins[3].port = PORTC_INDEX,
//     .keypad_rows_pins[3].pin = PIN3,
//     .keypad_rows_pins[3].direction = OUTPUT,
//     .keypad_rows_pins[3].logic = LOW,

//     .keypad_columns_pins[0].port = PORTC_INDEX,
//     .keypad_columns_pins[0].pin = PIN4,
//     .keypad_columns_pins[0].direction = INPUT,
//     .keypad_columns_pins[0].logic = LOW,

//     .keypad_columns_pins[1].port = PORTC_INDEX,
//     .keypad_columns_pins[1].pin = PIN5,
//     .keypad_columns_pins[1].direction = INPUT,
//     .keypad_columns_pins[1].logic = LOW,

//     .keypad_columns_pins[2].port = PORTC_INDEX,
//     .keypad_columns_pins[2].pin = PIN6,
//     .keypad_columns_pins[2].direction = INPUT,
//     .keypad_columns_pins[2].logic = LOW,

//     .keypad_columns_pins[3].port = PORTC_INDEX,
//     .keypad_columns_pins[3].pin = PIN7,
//     .keypad_columns_pins[3].direction = INPUT,
//     .keypad_columns_pins[3].logic = LOW,
// };

LCD_4bit_t lcd1 = {
    .lcd_en.port = PORTC_INDEX,
    .lcd_en.pin = PIN1,
    .lcd_en.direction = OUTPUT,
    .lcd_en.logic = LOW,

    .lcd_rs.port = PORTC_INDEX,
    .lcd_rs.pin = PIN0,
    .lcd_rs.direction = OUTPUT,
    .lcd_rs.logic = LOW,

    .lcd_data[0].port = PORTC_INDEX,
    .lcd_data[0].pin = PIN2,
    .lcd_data[0].logic = LOW,
    .lcd_data[0].direction = OUTPUT,

    .lcd_data[1].port = PORTC_INDEX,
    .lcd_data[1].pin = PIN3,
    .lcd_data[1].logic = LOW,
    .lcd_data[1].direction = OUTPUT,

    .lcd_data[2].port = PORTC_INDEX,
    .lcd_data[2].pin = PIN4,
    .lcd_data[2].logic = LOW,
    .lcd_data[2].direction = OUTPUT,

    .lcd_data[3].port = PORTC_INDEX,
    .lcd_data[3].pin = PIN5,
    .lcd_data[3].logic = LOW,
    .lcd_data[3].direction = OUTPUT,
};

LCD_8bit_t lcd2 = {
    .lcd_en.port = PORTC_INDEX,
    .lcd_en.pin = PIN7,
    .lcd_en.direction = OUTPUT,
    .lcd_en.logic = LOW,

    .lcd_rs.port = PORTC_INDEX,
    .lcd_rs.pin = PIN6,
    .lcd_rs.direction = OUTPUT,
    .lcd_rs.logic = LOW,

    .lcd_data[0].port = PORTD_INDEX,
    .lcd_data[0].pin = PIN0,
    .lcd_data[0].logic = LOW,
    .lcd_data[0].direction = OUTPUT,

    .lcd_data[1].port = PORTD_INDEX,
    .lcd_data[1].pin = PIN1,
    .lcd_data[1].logic = LOW,
    .lcd_data[1].direction = OUTPUT,

    .lcd_data[2].port = PORTD_INDEX,
    .lcd_data[2].pin = PIN2,
    .lcd_data[2].logic = LOW,
    .lcd_data[2].direction = OUTPUT,

    .lcd_data[3].port = PORTD_INDEX,
    .lcd_data[3].pin = PIN3,
    .lcd_data[3].logic = LOW,
    .lcd_data[3].direction = OUTPUT,

    .lcd_data[4].port = PORTD_INDEX,
    .lcd_data[4].pin = PIN4,
    .lcd_data[4].logic = LOW,
    .lcd_data[4].direction = OUTPUT,

    .lcd_data[5].port = PORTD_INDEX,
    .lcd_data[5].pin = PIN5,
    .lcd_data[5].logic = LOW,
    .lcd_data[5].direction = OUTPUT,

    .lcd_data[6].port = PORTD_INDEX,
    .lcd_data[6].pin = PIN6,
    .lcd_data[6].logic = LOW,
    .lcd_data[6].direction = OUTPUT,

    .lcd_data[7].port = PORTD_INDEX,
    .lcd_data[7].pin = PIN7,
    .lcd_data[7].logic = LOW,
    .lcd_data[7].direction = OUTPUT,
};

Std_ReturnType ret = E_NOT_OK;
uint8 val = 0;
uint8 string[6];

uint8 customChar[] = {0x02, 0x00, 0x04, 0x02, 0x01, 0x1F, 0x00, 0x00};

uint8 c2[] = {0x08, 0x00, 0x1C, 0x06, 0x0A, 0x11, 0x10, 0x0E};

int main()
{
    // app_init();

    // while(1){
    //     ret = keypad_get_key(&keypad, &val);
    // }

    app_init();

    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 20, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 19, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 18, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 17, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 16, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 15, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 14, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 13, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 12, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 11, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, customChar, 1, 10, 0);
    __delay_ms(100);
    lcd_4bit_send_custom_char(&lcd1, c2, 1, 9, 1);
    __delay_ms(100);
    while (1)
    {
    }

    return (EXIT_SUCCESS);
}

void app_init(void)
{
    // ret = keypad_init(&keypad);

    ret = lcd_4bit_init(&lcd1);
    ret = lcd_8bit_init(&lcd2);
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

******************************************************************* */
