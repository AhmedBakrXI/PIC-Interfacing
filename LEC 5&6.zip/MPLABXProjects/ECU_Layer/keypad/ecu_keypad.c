#include "ecu_keypad.h"

static const key_values[KEY_PAD_ROWS][KEY_PAD_COLUMNS] = {
                                                    {'7', '8', '9', '/'},
                                                    {'4', '5', '6', '*'},
                                                    {'1', '2', '3', '-'},
                                                    {'#', '0', '=', '+'},
                                                };

Std_ReturnType keypad_init(const Keypad_t *keypad)
{
    Std_ReturnType ret = E_OK;
    uint8 rows_counter = ZERO_INIT, columns_counter = ZERO_INIT;

    if(NULL == keypad){
        ret = E_NOT_OK;
    } else{
        for(rows_counter = ZERO_INIT; rows_counter < KEY_PAD_ROWS; rows_counter++){
            ret = gpio_pin_direction_init(&keypad->keypad_rows_pins[rows_counter]);
            ret = gpio_pin_write_logic(&keypad->keypad_rows_pins[rows_counter], 
                                        keypad->keypad_rows_pins[rows_counter].logic);
        }

        for(columns_counter = ZERO_INIT; columns_counter < KEY_PAD_COLUMNS; columns_counter++){
            ret = gpio_pin_direction_init(&keypad->keypad_columns_pins[columns_counter]);
            ret = gpio_pin_write_logic(&keypad->keypad_columns_pins[columns_counter], 
                                        keypad->keypad_columns_pins[columns_counter].logic);
        }
    }

    return ret;
}

Std_ReturnType keypad_get_key(const Keypad_t *keypad, uint8 *key)
{
    Std_ReturnType ret = E_OK;
    uint8 rows_counter = ZERO_INIT, columns_counter = ZERO_INIT, l_counter = ZERO_INIT;
    uint8 logic_val = ZERO_INIT; 

    if(NULL == keypad){
        ret = E_NOT_OK;
    } else{
        for(rows_counter = ZERO_INIT; rows_counter < KEY_PAD_ROWS; rows_counter++){
            for(l_counter = 0; l_counter < KEY_PAD_ROWS; l_counter++){
                ret = gpio_pin_write_logic(&(keypad->keypad_rows_pins[l_counter]), LOW);
            }
            
            ret = gpio_pin_write_logic(&(keypad->keypad_rows_pins[rows_counter]), HIGH);
            __delay_ms(50);
            for(columns_counter = 0; columns_counter < KEY_PAD_ROWS; columns_counter++){
                ret = gpio_pin_read_logic(&(keypad->keypad_columns_pins[columns_counter]), &logic_val);
                if(HIGH == logic_val){
                    *key = key_values[rows_counter][columns_counter];
                }
            }
        }
    }

    return ret;
}