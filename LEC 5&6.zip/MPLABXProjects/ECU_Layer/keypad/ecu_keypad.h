/* 
 * File:   ecu_keypad.h
 * Author: AHMED BAKR
 *
 * Created on July 22, 2023, 2:45 AM
 */

#ifndef ECU_KEYPAD_H
#define	ECU_KEYPAD_H

/*      SEC:    includes        */
#include "ecu_keypad_cfg.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*      SEC:    Macros Definitions      */

#define KEY_PAD_ROWS    4
#define KEY_PAD_COLUMNS 4

/*      SEC:    Macro Functions Definitions     */

/*      SEC:    User Defined Data types     */
typedef struct 
{
    pin_config_t keypad_rows_pins[KEY_PAD_ROWS];
    pin_config_t keypad_columns_pins[KEY_PAD_COLUMNS];
} Keypad_t;


/*      SEC:    Software Interfaces     */

/**
 * @brief 
 * 
 * @param keypad 
 * @return Std_ReturnType 
 */
Std_ReturnType keypad_init(const Keypad_t *keypad);

/**
 * @brief 
 * 
 * @param keypad 
 * @param key 
 * @return Std_ReturnType 
 */
Std_ReturnType keypad_get_key(const Keypad_t *keypad, uint8 *key);

#endif	/* ECU_KEYPAD_H */

