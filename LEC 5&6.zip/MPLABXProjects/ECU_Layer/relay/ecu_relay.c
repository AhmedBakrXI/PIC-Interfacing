/*
 * File:   ecu_relay.c
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 12:09 AM
 */

#include "ecu_relay.h"

Std_ReturnType relay_init(const Relay_t *relay)
{
    Std_ReturnType ret = E_OK;

    if (NULL == relay)
    {
        ret = E_NOT_OK;
    }
    else
    {
        pin_config_t relay_pin = {
            .port = relay->relay_port,
            .pin = relay->relay_pin,
            .logic = relay->relay_status,
            .direction = OUTPUT,
        };
        ret = gpio_pin_direction_init(&relay_pin);
    }

    return ret;
}

/**
 * @brief turns on the relay
 *
 * @param relay is a pointer to the relay object
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType relay_turn_on(const Relay_t *relay)
{
    Std_ReturnType ret = E_OK;

    if (NULL == relay)
    {
        ret = E_NOT_OK;
    }
    else
    {
        pin_config_t relay_pin = {
            .port = relay->relay_port,
            .pin = relay->relay_pin,
            .logic = relay->relay_status,
            .direction = OUTPUT,
        };
        ret = gpio_pin_write_logic(&relay_pin, HIGH);
    }

    return ret;
}

/**
 * @brief   turns off the relay
 *
 * @param relay is a pointer to the relay object
 * @return Std_ReturnType
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType relay_turn_off(const Relay_t *relay)
{
    Std_ReturnType ret = E_OK;

    if (NULL == relay)
    {
        ret = E_NOT_OK;
    }
    else
    {
        pin_config_t relay_pin = {
            .port = relay->relay_port,
            .pin = relay->relay_pin,
            .logic = relay->relay_status,
            .direction = OUTPUT,
        };
        ret = gpio_pin_write_logic(&relay_pin, LOW);
    }

    return ret;
}
