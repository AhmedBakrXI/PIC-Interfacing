/*
 * File:   ecu_lcd.h
 * Author: AHMED BAKR
 *
 * Created on July 22, 2023, 5:54 PM
 */

#ifndef ECU_LCD_H
#define ECU_LCD_H

/*
 * File:   ecu_keypad.h
 * Author: AHMED BAKR
 *
 * Created on July 22, 2023, 2:45 AM
 */

#ifndef ECU_KEYPAD_H
#define ECU_KEYPAD_H

/*      SEC:    includes        */
#include "ecu_lcd_cfg.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*      SEC:    Macros Definitions      */
#define LCD_CLEAR                        0x01    // replace all characters with ASCII 'space'
#define LCD_HOME                         0x02    // return cursor to first position on first line

#define LCD_ENTRY_MODE_DEC_SHIFT_OFF     0x04
#define LCD_ENTRY_MODE_DEC_SHIFT_ON      0x05  
#define LCD_ENTRY_MODE_INC_SHIFT_OFF     0x06
#define LCD_ENTRY_MODE_INC_SHIFT_ON      0x07


#define LCD_CURSOR_MOVE_SHIFT_LEFT       0x10
#define LCD_CURSOR_MOVE_SHIFT_RIGHT      0x14
#define LCD_DISPLAY_SHIFT_LEFT           0x18
#define LCD_DISPLAY_SHIFT_RIGHT          0x1C


#define LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_OFF   0x0C    // display on & cursor blink
#define LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_ON    0x0D 
#define LCD_DISPLAY_ON_UNDERLINE_ON_CURSOR_OFF    0x0E 
#define LCD_DISPLAY_ON_UNDERLINE_ON_CURSOR_ON     0x0F 
#define LCD_DISPLAY_OFF                           0x08 


#define LCD_Set5x7FontSize               0x20    // set font size to 5x7
#define LCD_FOUR_BIT_MODE                0x28    // select 4-bit mode
#define LCD_EIGHT_BIT_MODE               0x38

#define LCD_CGRAM_START                  0x40
#define LCD_DDRAM_START                  0x80


#define ROW1    1
#define ROW2    2
#define ROW3    3
#define ROW4    4


/*      SEC:    Macro Functions Definitions     */

/*      SEC:    User Defined Data types     */

typedef struct 
{
    pin_config_t lcd_rs;
    pin_config_t lcd_en;
    pin_config_t lcd_data[4];
} LCD_4bit_t;


typedef struct 
{
    pin_config_t lcd_rs;
    pin_config_t lcd_en;
    pin_config_t lcd_data[8];
} LCD_8bit_t;

/*      SEC:    Software Interfaces     */

Std_ReturnType lcd_4bit_init(const LCD_4bit_t *lcd);
Std_ReturnType lcd_4bit_send_command(const LCD_4bit_t *lcd, uint8 command);
Std_ReturnType lcd_4bit_send_char(const LCD_4bit_t *lcd, uint8 data);
Std_ReturnType lcd_4bit_send_char_pos(const LCD_4bit_t *lcd, uint8 data, 
                                                uint8 row, uint8 column);
Std_ReturnType lcd_4bit_send_string(const LCD_4bit_t *lcd, uint8 *str);
Std_ReturnType lcd_4bit_send_string_pos(const LCD_4bit_t *lcd, uint8 *str,
                                                uint8 row, uint8 column);
Std_ReturnType lcd_4bit_send_custom_char(const LCD_4bit_t *lcd, const uint8 data[],
                                            uint8 row, uint8 column, uint8 mem_pos);


Std_ReturnType lcd_8bit_init(const LCD_8bit_t *lcd);
Std_ReturnType lcd_8bit_send_command(const LCD_8bit_t *lcd, uint8 command);
Std_ReturnType lcd_8bit_send_char(const LCD_8bit_t *lcd, uint8 data);
Std_ReturnType lcd_8bit_send_char_pos(const LCD_8bit_t *lcd, uint8 data, 
                                                uint8 row, uint8 column);
Std_ReturnType lcd_8bit_send_string(const LCD_8bit_t *lcd, uint8 *str);
Std_ReturnType lcd_8bit_send_string_pos(const LCD_8bit_t *lcd, uint8 *str,
                                                uint8 row, uint8 column);
Std_ReturnType lcd_8bit_send_custom_char(const LCD_8bit_t *lcd, const uint8 data[],
                                            uint8 row, uint8 column, uint8 mem_pos);


Std_ReturnType convert_byte_to_str(uint8 value, uint8 *str);
Std_ReturnType convert_short_to_str(uint16 value, uint8 *str);
Std_ReturnType convert_int_to_str(uint32 value, uint8 *str);

#endif /* ECU_KEYPAD_H */
#endif /* ECU_LCD_H */
