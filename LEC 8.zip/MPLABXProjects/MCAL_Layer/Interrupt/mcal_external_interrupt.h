/*
 * File:   mcal_external_interrupt.h
 * Author: AHMED BAKR
 *
 * Created on July 26, 2023, 1:46 AM
 */

#ifndef MCAL_EXTERNAL_INTERRUPT_H
#define MCAL_EXTERNAL_INTERRUPT_H

/*  Section :   includes    */
#include "mcal_interrupt_cfg.h"

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

// INTX INTERRUPTS
#if INTERRUPT_INTX_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

#define INT0_INTERRUPT_ENABLE() (INTCONbits.INT0IE = 1)

#define INT0_INTERRUPT_DISABLE() (INTCONbits.INT0IE = 0)

#define INT0_CLEAR_FLAG() (INTCONbits.INT0IF = 0)

#define INT0_RISING_EDGE() (INTCON2bits.INTEDG0 = 1)

#define INT0_FALLING_EDGE() (INTCON2bits.INTEDG0 = 0)

#define INT1_INTERRUPT_ENABLE() (INTCON3bits.INT1IE = 1)

#define INT1_INTERRUPT_DISABLE() (INTCON3bits.INT1IE = 0)

#define INT1_CLEAR_FLAG() (INTCON3bits.INT1IF = 0)

#define INT1_RISING_EDGE() (INTCON2bits.INTEDG1 = 1)

#define INT1_FALLING_EDGE() (INTCON2bits.INTEDG1 = 0)

#define INT2_INTERRUPT_ENABLE() (INTCON3bits.INT2IE = 1)

#define INT2_INTERRUPT_DISABLE() (INTCON3bits.INT2IE = 0)

#define INT2_CLEAR_FLAG() (INTCON3bits.INT2IF = 0)

#define INT2_RISING_EDGE() (INTCON2bits.INTEDG2 = 1)

#define INT2_FALLING_EDGE() (INTCON2bits.INTEDG2 = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

#define INT1_SET_HIGH_PRIORITY() (INTCON3bits.INT1IP = 1)
#define INT1_SET_LOW_PRIORITY() (INTCON3bits.INT1IP = 0)

#define INT2_SET_HIGH_PRIORITY() (INTCON3bits.INT2IP = 1)
#define INT2_SET_LOW_PRIORITY() (INTCON3bits.INT2IP = 0)

#endif

#endif

// PORTB ON CHANGE INTERRUPTS
#if INTERRUPT_OnChange_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

#define INTERRUPT_RBX_ENABLE() (INTCONbits.RBIE = 1)
#define INTERRUPT_RBX_DISABLE() (INTCONbits.RBIE = 0)

#define INTERRUPT_RBX_CLEAR_FLAG() (INTCONbits.RBIF = 0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE == INTERRUPT_FEATURE_ENABLE

#define INTERRUPT_RBX_SET_HIGH_PRIORITY() (INTCON2bits.RBIP = 1)
#define INTERRUPT_RBX_SET_LOW_PRIORITY() (INTCON2bits.RBIP = 0)

#endif

#endif

/*  Section :   Data Type Declarations    */

typedef enum
{
    FALLING_EDGE = 0,
    RISING_EDGE,
} Interrupt_INTx_edge;

typedef enum
{
    INT0_INTERRUPT = 0,
    INT1_INTERRUPT,
    INT2_INTERRUPT,
} Interrupt_INTx_src;

typedef struct
{
    pin_config_t pin;
    Interrupt_INTx_edge edge;
    Interrupt_INTx_src source;
    Interrupt_priority priority;
    void (*interrupt_handler)(void);
} Interrupt_INTx_t;

typedef struct
{
    pin_config_t pin;
    Interrupt_priority priority;
    void (*interrupt_handler_high)(void);
    void (*interrupt_handler_low)(void);
} Interrupt_RBx_t;

/*  Section :   Software Interfaces    */

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_INTx_init(const Interrupt_INTx_t *_intx);

/**
 * @brief 
 * 
 * @param _intx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_INTx_cancel(const Interrupt_INTx_t *_intx);

/**
 * @brief a
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_RBx_init(const Interrupt_RBx_t *_RBx);

/**
 * @brief 
 * 
 * @param _RBx 
 * @return Std_ReturnType 
 */
Std_ReturnType Interrupt_RBx_cancel(const Interrupt_RBx_t *_RBx);

#endif /* MCAL_EXTERNAL_INTERRUPT_H */
