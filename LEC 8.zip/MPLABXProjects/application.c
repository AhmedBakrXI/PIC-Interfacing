/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

uint8 data;

Std_ReturnType ret = E_NOT_OK;

int main()
{
    ret = EEPROM_write_data(0x255, 0xF4);
    ret = EEPROM_read_data(0x255, &data);
    while (1)
    {
    }

    return (EXIT_SUCCESS);
}

void app_init(void)
{
    ecu_layer_init();
}


// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture

Ahmed Mohammed Bakr     19July2023      Task-2 build GPIO driver

Ahmed Mohammed Bakr     20July2023      Task-3 build LCD driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver

Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver

Ahmed Mohammed Bakr     22July2023      Task-8 build 7 segment display driver
Ahmed Mohammed Bakr     22July2023      Task-9 build Keypad driver
Ahmed Mohammed Bakr     22July2023      Task-10 build LCD driver

Ahmed Mohammed Bakr     26July2023      Task-11 build mcal external interrupt

Ahmed Mohammed Bakr     27July2023      Task-12 build mcal EEPROM interrupt

******************************************************************* */
