#include "ecu_layer_init.h"



void ecu_layer_init(void)
{
    // ret = keypad_init(&keypad);

    lcd_4bit_init(&lcd1);
    lcd_8bit_init(&lcd2);
}