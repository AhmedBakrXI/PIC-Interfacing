/* 
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 5:40 PM
 */
#include "ecu_led.h"
