/* 
 * File:   ecu_led.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:36 PM
 */

#ifndef ECU_LED_H
#define	ECU_LED_H

#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*  Section :   includes    */

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */
#endif	/* ECU_LED_H */

