/* 
 * File:   application.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:42 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H

#include "ECU_Layer/led/ecu_led.h"
/*  Section :   includes    */

/*  Section :   Macro Declarations    */
#define _XTAL_FREQ  4000000
/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

void app_init(void);

#endif	/* APPLICATION_H */

