/* 
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

pin_config_t led1 = {
  .port = PORTC_INDEX,
  .pin = PIN0,
  .logic = HIGH,
  .direction = OUTPUT
};

pin_config_t led2 = {
  .port = PORTC_INDEX,
  .pin = PIN1,
  .logic = LOW,
  .direction = OUTPUT
};

pin_config_t led3 = {
  .port = PORTC_INDEX,
  .pin = PIN2,
  .logic = HIGH,
  .direction = OUTPUT
};

pin_config_t led4 = {
  .port = PORTC_INDEX,
  .pin = PIN3,
  .logic = LOW,
  .direction = OUTPUT
};

pin_config_t btn = {
  .port = PORTD_INDEX,
  .pin = PIN0,
  .logic = LOW,
  .direction = INPUT
};

uint8 direc_status;

direction_t led_dir;

logic_t btn_logic;

Std_ReturnType ret = E_NOT_OK;
    
int main() {
    app_init();
ret = gpio_pin_write_logic(&led2, HIGH);
    while(1){      
        ret = gpio_port_toggle_logic(PORTC_INDEX);
        __delay_ms(500);
    }
    
    return (EXIT_SUCCESS);
}

void app_init(void){
//    ret = gpio_pin_direction_init(&btn);
//    ret = gpio_pin_direction_init(&led1);
//    ret = gpio_pin_write_logic(&led1, HIGH);
//    ret = gpio_pin_direction_init(&led2);
//    ret = gpio_pin_write_logic(&led2, HIGH);
//    ret = gpio_pin_direction_init(&led3);
//    ret = gpio_pin_write_logic(&led3, HIGH);
//    ret = gpio_pin_direction_init(&led4);
//    ret = gpio_pin_write_logic(&led4, LOW);
//    ret = gpio_pin_get_direction_status(&led1, &led_dir);
    ret = gpio_port_direction_init(PORTC_INDEX, 0x00);
    ret = gpio_port_get_direction_status(PORTC_INDEX, &direc_status);
    ret = gpio_port_write_logic(PORTC_INDEX, 0xFF);
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     15July2023      Task-1 Add print Welcome
Ahmed Mohammed Bakr     15July2023      Task-2 Add print A
******************************************************************* */
