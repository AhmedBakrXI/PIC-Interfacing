/*
 * File:   application.c
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 3:06 PM
 */

#include "application.h"

// pin_config_t led1 = {
//   .port = PORTC_INDEX,
//   .pin = PIN0,
//   .logic = HIGH,
//   .direction = OUTPUT
// };
//
// pin_config_t led2 = {
//   .port = PORTC_INDEX,
//   .pin = PIN1,
//   .logic = LOW,
//   .direction = OUTPUT
// };
//
// pin_config_t led3 = {
//   .port = PORTC_INDEX,
//   .pin = PIN2,
//   .logic = HIGH,
//   .direction = OUTPUT
// };
//
// pin_config_t led4 = {
//   .port = PORTC_INDEX,
//   .pin = PIN3,
//   .logic = LOW,
//   .direction = OUTPUT
// };
//
// pin_config_t btn = {
//   .port = PORTD_INDEX,
//   .pin = PIN0,
//   .logic = LOW,
//   .direction = INPUT
// };
//
// uint8 direc_status;
//
// direction_t led_dir;
//
// logic_t btn_logic;

/*  Button  */
// led_t led = {
//     .port = PORTC_INDEX,
//     .pin = PIN6,
//     .status = LED_ON
// };

// button_t btn_high = {
//     .btn_pin.port = PORTD_INDEX,
//     .btn_pin.pin = PIN0,
//     .btn_pin.direction = INPUT,
//     .btn_pin.logic = LOW,
//     .button_active = ACTIVE_HIGH,
//     .button_state = BTN_RELEASED,
// };

// button_t btn_low = {
//     .btn_pin.port = PORTD_INDEX,
//     .btn_pin.pin = PIN1,
//     .btn_pin.direction = INPUT,
//     .btn_pin.logic = HIGH,
//     .button_active = ACTIVE_LOW,
//     .button_state = BTN_RELEASED,
// };

// button_state_t status = BTN_RELEASED;

/*  Relay   */
// Relay_t _relay = {
//     .relay_port = PORTC_INDEX,
//     .relay_pin = PIN0,
//     .relay_status = RELAY_OFF,
// };

/*      DC MOTOR TEST       */

// DC_Motor_t dc_motor1 = {
//     .motor_pin[0].port = PORTC_INDEX,
//     .motor_pin[0].pin = PIN0,
//     .motor_pin[0].logic = MOTOR_OFF,
//     .motor_pin[0].direction = OUTPUT,

//     .motor_pin[1].port = PORTC_INDEX,
//     .motor_pin[1].pin = PIN1,
//     .motor_pin[1].logic = MOTOR_OFF,
//     .motor_pin[1].direction = OUTPUT,
// };

// DC_Motor_t dc_motor2 = {
//     .motor_pin[0].port = PORTC_INDEX,
//     .motor_pin[0].pin = PIN2,
//     .motor_pin[0].logic = MOTOR_OFF,
//     .motor_pin[0].direction = OUTPUT,

//     .motor_pin[1].port = PORTC_INDEX,
//     .motor_pin[1].pin = PIN3,
//     .motor_pin[1].logic = MOTOR_OFF,
//     .motor_pin[1].direction = OUTPUT,
// };

/*********** 2 DIGIT COUNTER ************/
Segment_t segment = {
    .seg_pins[SEG_PIN0].port = PORTC_INDEX,
    .seg_pins[SEG_PIN0].pin = PIN0,
    .seg_pins[SEG_PIN0].logic = LOW,
    .seg_pins[SEG_PIN0].direction = OUTPUT,

    .seg_pins[SEG_PIN1].port = PORTC_INDEX,
    .seg_pins[SEG_PIN1].pin = PIN1,
    .seg_pins[SEG_PIN1].logic = LOW,
    .seg_pins[SEG_PIN1].direction = OUTPUT,

    .seg_pins[SEG_PIN2].port = PORTC_INDEX,
    .seg_pins[SEG_PIN2].pin = PIN2,
    .seg_pins[SEG_PIN2].logic = LOW,
    .seg_pins[SEG_PIN2].direction = OUTPUT,

    .seg_pins[SEG_PIN3].port = PORTC_INDEX,
    .seg_pins[SEG_PIN3].pin = PIN3,
    .seg_pins[SEG_PIN3].logic = LOW,
    .seg_pins[SEG_PIN3].direction = OUTPUT,

    .segment_type = COMMON_CATHODE,
};

pin_config_t seg_en1 = {
    .port = PORTD_INDEX,
    .pin = PIN0,
    .logic = LOW,
    .direction = OUTPUT,
};

pin_config_t seg_en2 = {
    .port = PORTD_INDEX,
    .pin = PIN1,
    .logic = LOW,
    .direction = OUTPUT,
};

Std_ReturnType ret = E_NOT_OK;

int main()
{
    //    app_init();
    //    ret = gpio_pin_write_logic(&led2, HIGH);
    //    while(1){
    //        ret = gpio_port_toggle_logic(PORTC_INDEX);
    //        __delay_ms(500);
    //    }

    /*  Button  */
    // led_initialize(&led);
    // ret = btn_init(&btn_high);
    // ret = btn_init(&btn_low);

    // while(1){
    //     btn_read(&btn_low, &status);
    //     if(BTN_PRESSED == status)
    //     {
    //         led_turn_on(&led);
    //     }
    //     else
    //     {
    //         led_turn_off(&led);
    //     }
    // }

    /*  relay test   */

    // ret = relay_init(&_relay);

    // while (1)
    // {
    //     ret = relay_turn_on(&_relay);
    //     __delay_ms(3000);
    //     ret = relay_turn_off(&_relay);
    //     __delay_ms(3000);
    // }

    /*      DC MOTOR TEST       */

    // app_init();

    // while (1)
    // {
    //     ret = dc_motor_right(&dc_motor1);
    //     ret = dc_motor_left(&dc_motor2);
    //     __delay_ms(1000);

    //     ret = dc_motor_stop(&dc_motor1);
    //     ret = dc_motor_stop(&dc_motor2);
    //     __delay_ms(1000);

    //     ret = dc_motor_left(&dc_motor1);
    //     ret = dc_motor_right(&dc_motor2);
    //     __delay_ms(1000);
    // }

    /******* 2 DIGIT COUNTER ********/
    app_init();

    uint8 counter = 1;
    uint8 i = 0;
    while (1)
    {
        for (i = 0; i < 20; i++)
        {
            ret = seven_seg_write(&segment, counter / 10);
            ret = gpio_pin_write_logic(&seg_en2, HIGH);
            __delay_ms(70);
            ret = gpio_pin_write_logic(&seg_en2, LOW);

            ret = seven_seg_write(&segment, counter % 10);
            ret = gpio_pin_write_logic(&seg_en1, HIGH);
            __delay_ms(70);
            ret = gpio_pin_write_logic(&seg_en1, LOW);
        }

        counter++;
        if (counter == 100)
        {
            counter = 0;
        }
    }

    return (EXIT_SUCCESS);
}

void app_init(void)
{
    //    ret = gpio_pin_direction_init(&btn);
    //    ret = gpio_pin_direction_init(&led1);
    //    ret = gpio_pin_write_logic(&led1, HIGH);
    //    ret = gpio_pin_direction_init(&led2);
    //    ret = gpio_pin_write_logic(&led2, HIGH);
    //    ret = gpio_pin_direction_init(&led3);
    //    ret = gpio_pin_write_logic(&led3, HIGH);
    //    ret = gpio_pin_direction_init(&led4);
    //    ret = gpio_pin_write_logic(&led4, LOW);
    //    ret = gpio_pin_get_direction_status(&led1, &led_dir);
    //    ret = gpio_port_direction_init(PORTC_INDEX, 0x00);
    //    ret = gpio_port_get_direction_status(PORTC_INDEX, &direc_status);
    //    ret = gpio_port_write_logic(PORTC_INDEX, 0xFF);

    // ret = dc_motor_init(&dc_motor1);
    // ret = dc_motor_init(&dc_motor2);

    ret = seven_seg_init(&segment);
    ret = gpio_pin_direction_init(&seg_en1);
    ret = gpio_pin_direction_init(&seg_en2);
}

// History log
/* ******************************************************************
User                    Date            Brief
*********************************************************************
Ahmed Mohammed Bakr     18July2023      Task-1 build the project architecture
Ahmed Mohammed Bakr     19July2023      Task-2 build hal_gpio driver
Ahmed Mohammed Bakr     20July2023      Task-3 build lcd driver
Ahmed Mohammed Bakr     20July2023      Task-4 build button driver
Ahmed Mohammed Bakr     21July2023      Task-5 build relay driver
Ahmed Mohammed Bakr     21July2023      Task-6 build DC motor driver
Ahmed Mohammed Bakr     21July2023      Task-7 build 7 segment display driver
******************************************************************* */
