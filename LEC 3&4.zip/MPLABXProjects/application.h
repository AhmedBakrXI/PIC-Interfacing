/* 
 * File:   application.h
 * Author: AHMED BAKR
 *
 * Created on July 18, 2023, 4:42 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H

/*  Section :   includes    */
#include "ECU_Layer/led/ecu_led.h"
#include "ECU_Layer/button/ecu_button.h"
#include "ECU_Layer/relay/ecu_relay.h"
#include "ECU_Layer/dc_motor/ecu_dc_motor.h"
#include "ECU_Layer/7SEG_Display/ecu_7seg.h"



/*  Section :   Macro Declarations    */
#define _XTAL_FREQ  8000000UL
/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

void app_init(void);

#endif	/* APPLICATION_H */

