#include "ecu_button.h"

/**
 * @brief Initialize the assigned pin to be Input.
 * @param btn pointer to the button configurations
 * @return  Status of the function
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType btn_init(const button_t *btn)
{
    Std_ReturnType ret = E_OK;

    if (NULL == btn)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_direction_init(&(btn->btn_pin));
    }

    return ret;
}

/**
 * @brief Read the state of the button
 * @param btn pointer to the button configurations
 * @param btn_state button state @ref button_state_t
 * @return  Status of the function
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType btn_read(const button_t *btn, button_state_t *btn_state)
{
    Std_ReturnType ret = E_OK;
    logic_t btn_logic = LOW;

    if (NULL == btn)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_read_logic(&btn->btn_pin, &btn_logic);
        if (ACTIVE_HIGH == btn->button_active)
        {
            if (HIGH == btn_logic)
            {
                *btn_state = BTN_PRESSED;
            }
            else
            {
                *btn_state = BTN_RELEASED;
            }  
        }
        else if (ACTIVE_LOW == btn->button_active)
        {
            if (LOW == btn_logic)
            {
                *btn_state = BTN_PRESSED;
            }
            else
            {
                *btn_state = BTN_RELEASED;
            }
        }
        else
        {
            /*Nothing*/
        }
    }

    return ret;
}
