/* 
 * File:   ecu_dc_motor.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 2:57 PM
 */

#ifndef ECU_DC_MOTOR_H
#define	ECU_DC_MOTOR_H

#include "ecu_dc_motor_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*  Section :   Macro Declarations    */

#define MOTOR_ON    0x01U
#define MOTOR_OFF   0x00U

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */


typedef struct {
    pin_config_t motor_pin[2];
} DC_Motor_t;



/*  Section :   Function Declarations    */

/**
 * @brief Initializes the motor pins
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_init(const DC_Motor_t *_dc_motor);

/**
 * @brief Turns motor left
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_left(const DC_Motor_t *_dc_motor);

/**
 * @brief Turns motor right
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_right(const DC_Motor_t *_dc_motor);

/**
 * @brief Stops the motor
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_stop(const DC_Motor_t *_dc_motor);


#endif	/* ECU_DC_MOTOR_H */

