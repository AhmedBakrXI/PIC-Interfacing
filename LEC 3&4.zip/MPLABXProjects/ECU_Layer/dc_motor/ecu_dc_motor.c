#include "ecu_dc_motor.h"


/**
 * @brief Initializes the motor pins
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_init(const DC_Motor_t *_dc_motor)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _dc_motor)
    {
        ret = E_NOT_OK;
    }
    else
    {
        
        ret = gpio_pin_direction_init(&_dc_motor->motor_pin[0]);
        ret = gpio_pin_direction_init(&_dc_motor->motor_pin[1]);
    }

    return ret;
}

/**
 * @brief Turns motor left
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_left(const DC_Motor_t *_dc_motor)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _dc_motor)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[0], HIGH);
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[1], LOW);
    }

    return ret;
}

/**
 * @brief Turns motor right
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_right(const DC_Motor_t *_dc_motor)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _dc_motor)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[1], HIGH);
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[0], LOW);
    }

    return ret;
}


/**
 * @brief Stops the motor
 * 
 * @param _dc_motor pointer to the motor configurations 
 * @return Std_ReturnType 
 *          (E_OK) : The function done successfully
 *          (E_NOT_OK) : The function has issue while performing this action
 */
Std_ReturnType dc_motor_stop(const DC_Motor_t *_dc_motor)
{
    Std_ReturnType ret = E_OK;

    if (NULL == _dc_motor)
    {
        ret = E_NOT_OK;
    }
    else
    {
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[0], LOW);
        ret = gpio_pin_write_logic(&_dc_motor->motor_pin[1], LOW);
    }

    return ret;
}