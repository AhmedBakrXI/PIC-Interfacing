/* 
 * File:   ecu_dc_motor_config.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 2:58 PM
 */

#ifndef ECU_DC_MOTOR_CONFIG_H
#define	ECU_DC_MOTOR_CONFIG_H



#endif	/* ECU_DC_MOTOR_CONFIG_H */

