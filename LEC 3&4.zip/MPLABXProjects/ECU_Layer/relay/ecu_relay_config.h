/* 
 * File:   ecu_relay_config.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 12:10 AM
 */

#ifndef ECU_RELAY_CONFIG_H
#define	ECU_RELAY_CONFIG_H


#endif	/* ECU_RELAY_CONFIG_H */

