/* 
 * File:   ecu_led_config.h
 * Author: AHMED BAKR
 *
 * Created on July 20, 2023, 3:18 PM
 */

#ifndef ECU_LED_CONFIG_H
#define	ECU_LED_CONFIG_H



#endif	/* ECU_LED_CONFIG_H */

