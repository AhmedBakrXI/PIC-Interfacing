/* 
 * File:   ecu_led.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:36 PM
 */

#ifndef ECU_LED_H
#define	ECU_LED_H

/*  Section :   includes    */
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "ecu_led_config.h"


/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

typedef enum {
    LED_OFF = 0,
    LED_ON
} led_status_t;

typedef struct {
    uint8 port      :4;
    uint8 pin       :3;
    uint8 status    :1;
} led_t;

/*  Section :   Function Declarations    */

Std_ReturnType led_initialize(const led_t *led);
Std_ReturnType led_turn_on(const led_t *led);
Std_ReturnType led_turn_off(const led_t *led);
Std_ReturnType led_turn_toggle(const led_t *led);

#endif	/* ECU_LED_H */

