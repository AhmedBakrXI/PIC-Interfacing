#include "ecu_7seg.h"


Std_ReturnType seven_seg_init(const Segment_t *_segment){
    Std_ReturnType ret = E_OK;
    
    if(NULL == _segment){
        ret = E_NOT_OK;
    } else{
        ret = gpio_pin_direction_init(&_segment->seg_pins[SEG_PIN0]);
        ret = gpio_pin_direction_init(&_segment->seg_pins[SEG_PIN1]);
        ret = gpio_pin_direction_init(&_segment->seg_pins[SEG_PIN2]);
        ret = gpio_pin_direction_init(&_segment->seg_pins[SEG_PIN3]);

        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN0], _segment->seg_pins[SEG_PIN0].logic);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN1], _segment->seg_pins[SEG_PIN1].logic);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN2], _segment->seg_pins[SEG_PIN2].logic);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN3], _segment->seg_pins[SEG_PIN3].logic);
    }

    return ret;
}


Std_ReturnType seven_seg_write(const Segment_t *_segment, uint8 number){
    Std_ReturnType ret = E_OK;
    
    if((NULL == _segment) || (number > 9)){
        ret = E_NOT_OK;
    } else{
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN0], (number >> 0) & 0x01);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN1], (number >> 1) & 0x01);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN2], (number >> 2) & 0x01);
        ret = gpio_pin_write_logic(&_segment->seg_pins[SEG_PIN3], (number >> 3) & 0x01);
    }

    return ret;
}
