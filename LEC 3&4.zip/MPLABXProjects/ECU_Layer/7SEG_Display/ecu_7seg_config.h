/* 
 * File:   ecu_7seg_config.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 9:37 PM
 */

#ifndef ECU_7SEG_CONFIG_H
#define	ECU_7SEG_CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ECU_7SEG_CONFIG_H */

