/* 
 * File:   ecu_7seg.h
 * Author: AHMED BAKR
 *
 * Created on July 21, 2023, 9:37 PM
 */

#ifndef ECU_7SEG_H
#define	ECU_7SEG_H

/*  Sec:    Includes    */
#include "ecu_7seg_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"

/*  Sec:    Macros Definition   */

#define SEG_PIN0    0
#define SEG_PIN1    1
#define SEG_PIN2    2
#define SEG_PIN3    3


/*  Sec:    User Defined Data Types*/
typedef enum{
    COMMON_CATHODE,
    COMMON_ANODE
} segment_type_t;

typedef struct 
{
    pin_config_t seg_pins[4];
    segment_type_t segment_type;
} Segment_t;


/*  Sec:    Functions Declaration*/

Std_ReturnType seven_seg_init(const Segment_t *_segment);
Std_ReturnType seven_seg_write(const Segment_t *_segment, uint8 number);


#endif	/* ECU_7SEG_H */

