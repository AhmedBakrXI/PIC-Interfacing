/* 
 * File:   std_library.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:13 PM
 */

#ifndef STD_LIBRARY_H
#define	STD_LIBRARY_H

#include <stdio.h>
#include <stdlib.h>

/*  Section :   includes    */

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif	/* STD_LIBRARY_H */

