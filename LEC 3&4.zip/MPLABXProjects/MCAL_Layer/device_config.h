/* 
 * File:   device_config.h
 * Author: AHMED BAKR
 *
 * Created on July 17, 2023, 4:50 PM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

/*  Section :   includes    */

/*  Section :   Macro Declarations    */

/*  Section :   Macro Functions Declarations    */

/*  Section :   Data Type Declarations    */

/*  Section :   Function Declarations    */

#endif	/* DEVICE_CONFIG_H */

